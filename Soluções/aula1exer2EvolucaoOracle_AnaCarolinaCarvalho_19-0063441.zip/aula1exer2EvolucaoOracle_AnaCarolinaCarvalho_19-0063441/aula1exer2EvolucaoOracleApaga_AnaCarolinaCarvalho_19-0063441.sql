﻿-- -------- << Aula 1 Exercicio 2 Evolucao Oracle Apaga >>   ------- --
--                                                                   --
--                    SCRIPT DE REMO��O                              --
--                                                                   --
-- Data Criacao ..........: 26/03/2018                               --
-- Autor(es) .............: Ana Carolina Carvalho da Silva           --  
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: bdAula1Exer2Evol3                        --
--                                                                   --
-- Data Ultima Alteracao ..: 25/04/2019                              --
--    + Remocao do banco de dados                                    --
--                                                                   --
-- PROJETO => 01 Base de Dados                                       --
--         => 12 Tabelas                                             --
--         => 02 Usuarios                                            --
--                                                                   --
-- ----------------------------------------------------------------- --

USE bdAula1Exer2Evol3;

DROP TABLE AS_administra;
DROP TABLE AS_pertence;
DROP TABLE AS_possui;
DROP TABLE AS_realiza;
DROP TABLE AS_gerencia;
DROP TABLE AS_telefone;
DROP TABLE AS_VENDA;
DROP TABLE AS_PRODUTO;
DROP TABLE AS_AREA;
DROP TABLE AS_EMPREGADO;
DROP TABLE AS_GERENTE;
DROP TABLE AS_PESSOA;
