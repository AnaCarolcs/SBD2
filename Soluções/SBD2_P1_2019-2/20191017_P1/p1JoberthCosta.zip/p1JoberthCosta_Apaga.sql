-- --------     <<P1 >>     ------------
-- 
--                    SCRIPT APAGA(DDL)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Joberth Rogers Tavares Costa
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: joberthcosta
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de script apaga
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
-- 
-- -----------------------------------------------------------------

USE joberthcosta;

DROP TABLE possui;
DROP TABLE relaciona;
DROP TABLE email;
DROP TABLE CARACTERISTICA ;
DROP TABLE PESSOA;
