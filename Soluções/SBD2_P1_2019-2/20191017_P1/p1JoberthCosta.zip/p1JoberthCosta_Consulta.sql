-- --------     <<P1 >>     ------------
-- 
--                    SCRIPT CONSULTA(DML)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Joberth Rogers Tavares Costa
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: joberthcosta
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de script consulta
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
-- 
-- -----------------------------------------------------------------

USE joberth costa

-- O indice abaixo ajuda na procuta pelo nome das pessoas
-- assim criando uma tabela alternativa que busca de forma inteligente 
-- usando ordenação e em um tempo menor

CREATE INDEX CARACTERISTICAS_IDX ON PESSO (nome);

-- Essa view ajuda os usuarios ver todas as caracteriscas de usuario
-- de forma facil e rápida, sem precisar fazer um select enorme envolvendo todas essas tabelas

CREATE VIEW V_CARACTERISTICAS_PESSOA (cpf, nome, hobbie) AS
	SELECT p.cpf, p.nome, c.hobbie
	FROM PESSOA p
	INNER JOIN possui po ON po.cpf = p.cpf
	INNER JOIN CARACTERISTICA c ON c.codigo = po.codigo;

