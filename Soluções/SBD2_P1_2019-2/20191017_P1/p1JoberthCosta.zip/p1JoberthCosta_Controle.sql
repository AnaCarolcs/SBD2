-- --------     <<P1 >>     ------------
-- 
--                    SCRIPT DE CRONTROLE(DDL)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Joberth Rogers Tavares Costa
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: joberthcosta
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de script controle
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
-- 
-- -----------------------------------------------------------------

CREATE USER 'ADMIN' IDENTIFIED BY 'admin';
GRANT ALL PRIVILEGES ON joberthcosta.* TO ADMIN;

CREATE USER 'PESSOA' IDENTIFIED BY 'pessoa';
GRANT SELECT ON joberthcosta.* TO PESSOA;