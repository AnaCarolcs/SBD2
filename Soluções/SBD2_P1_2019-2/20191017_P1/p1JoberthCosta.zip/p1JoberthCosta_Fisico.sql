-- --------     <<P1 >>     ------------
-- 
--                    SCRIPT FISICO(DDL)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Joberth Rogers Tavares Costa
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: joberthcosta
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de script fisico
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
-- 
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS joberthrogers;
USE joberthcosta;

CREATE TABLE PESSOA (
    nome VARCHAR(255) NOT NULL,
    cpf VARCHAR(15) NOT NULL,
    dataNascimento DATE NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
    CONSTRAINT PESSOA_PK PRIMARY KEY (cpf)
)ENGINE=InnoDb;

CREATE TABLE CARACTERISTICA (
    codigo INTEGER AUTO_INCREMENT ,
    nome VARCHAR(255) NOT NULL,
    hobbie VARCHAR(255) NOT NULL,
    CONSTRAINT CARACTERISTICA_PK PRIMARY KEY (codigo)
)ENGINE=InnoDb AUTO_INCREMENT=1;

CREATE TABLE email (
    cpf VARCHAR(20) NOT NULL,
    email VARCHAR(30) NOT NULL,
    CONSTRAINT email_PESSOA_FK FOREIGN KEY (cpf) REFERENCES PESSOA (cpf) 
    ON DELETE RESTRICT
    ON UPDATE RESTRICT
)ENGINE=InnoDb;

CREATE TABLE relaciona (
    cpf VARCHAR(15) NOT NULL,
    cpf_relacionamento VARCHAR(15) NOT NULL,
    CONSTRAINT relaciona_PESSOA_FK FOREIGN KEY (cpf) REFERENCES PESSOA (cpf) 
    ON DELETE RESTRICT
    ON UPDATE RESTRICT,
    CONSTRAINT relaciona_PESSOA2_FK FOREIGN KEY (cpf_relacionamento) REFERENCES PESSOA (cpf) 
    ON DELETE RESTRICT
    ON UPDATE RESTRICT

)ENGINE=InnoDb;

CREATE TABLE possui (
    cpf VARCHAR(15) NOT NULL,
    codigo INTEGER NOT NULL,
    CONSTRAINT possui_PESSOA_FK FOREIGN KEY (cpf) REFERENCES PESSOA (cpf) 
    ON DELETE RESTRICT
    ON UPDATE RESTRICT,
    CONSTRAINT possui_CARACTERISTICA_FK FOREIGN KEY (cpf_relacionamento) REFERENCES CARACTERISTICA (codigo) 
    ON DELETE RESTRICT
    ON UPDATE RESTRICT
)ENGINE=InnoDb;
 