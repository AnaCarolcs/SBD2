-- --------     <<P1 >>     ------------
-- 
--                    SCRIPT POPULA(DML)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Joberth Rogers Tavares Costa
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: joberthcosta
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de script popula
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
-- 
-- -----------------------------------------------------------------

USE joberthcosta;

INSERT INTO PESSOA (cpf, nome, dataNascimento, sexo) VALUES ( '0657705105', 'Augusto', '1995-05-05', 'M' ), 
								( '7705105111', 'Eduardo Lima', '1995-10-05', 'M' ),
								( '0657712345', 'Joberth Rogers', '1995-06-05', 'M' );



INSERT INTO CARACTERISTICA (nome, hobbie) VALUES ('Atleta', 'karate' ), 
								( 'Estudioso', 'Estudo fisico' ),
								( 'Zen', 'Good vibes' );

INSERT INTO email (cpf, email) VALUES ('0657705105', 'augusto@gmail.com'), ('7705105111','teste@gmail.com' ), ('0657712345', 'teste2@gmail.co');

INSERT INTO relaciona (cpf, cpf_relacionamento ) VALUES ('0657705105', '7705105111'), ('7705105111', '0657712345'), ('0657705105', '0657712345');

INSERT INTO possui (cpf, codigo) VALUES ('0657705105',1 ), ('7705105111', 2), ('0657712345', 3);