﻿-- --------     << p1DjorkaeffPereira >>     ------------
--
--                    SCRIPT DE APAGAR (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Djorkaeff Alexandre Vilela Pereira
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: p1DjorkaeffPereira
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de script de apaga
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
--         => 01 Visoes
--
-- -----------------------------------------------------------------

USE p1DjorkaeffPereira;

DROP TABLE email;
DROP TABLE possui;
DROP TABLE CARACTERISTICA;
DROP TABLE relacionamento;
DROP TABLE PESSOA;