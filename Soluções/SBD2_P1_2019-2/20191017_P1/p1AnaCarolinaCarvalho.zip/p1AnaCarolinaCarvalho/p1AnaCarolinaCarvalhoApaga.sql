﻿-- --------     << PESSOA >>     ------------
--
--                    SCRIPT DE APAGA
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Ana Carolina Carvalho
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: anasilva
--
-- Data Ultima Alteracao ..: 17/10/2019
--
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
--
-- ----------------------------------------------------
-- Apaga:

use anasilva;

DROP TABLE possui;
DROP TABLE tem;

DROP TABLE PESSOA;
DROP TABLE CARACTERISTICA;
DROP TABLE RELACIONAMENTO;
