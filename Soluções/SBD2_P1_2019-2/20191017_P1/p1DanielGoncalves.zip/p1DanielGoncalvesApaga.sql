
-- --------            << DanielGoncalves >>        ------------ --
--                                                                   --
--                    SCRIPT DE APAGA (DDL)                        --
--                                                                   --
-- Data Criacao ..........: 17/10/2019                               --
-- Autor(es) .............: Daniel Maike Mendes Gonçalves            --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: DanielGoncalves                      --
--                                                                   --
-- Data Ultima Alteracao ..: 17/10/2019                              --
--    + Deletando tabela por tabela                                    --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 9 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --

USE DanielGoncalves;

DROP TABLE requisita;
DROP TABLE matricula;
DROP TABLE formado;
DROP TABLE leciona;
DROP TABLE email;
DROP TABLE ALUNO;
DROP TABLE PROFESSOR;
DROP TABLE DISCIPLINA;
DROP TABLE CURSO;