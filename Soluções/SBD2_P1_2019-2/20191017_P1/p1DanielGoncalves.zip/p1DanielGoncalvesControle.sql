
-- --------            << DanielGoncalves >>        ------------ --
--                                                                   --
--                    SCRIPT DE CONTROLE (DDL/DCL)                        --
--                                                                   --
-- Data Criacao ..........: 17/10/2019                               --
-- Autor(es) .............: Daniel Maike Mendes Gonçalves            --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: DanielGoncalves                      --
--                                                                   --
-- Data Ultima Alteracao ..: 17/10/2019                              --
--    + Criacao de usuarios e permissoes                                    --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 9 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --

USE DanielGoncalves;

CREATE USER 'administrador' IDENTIFIED BY 'adimn';
GRANT CREATE, DROP, SELECT, UPDATE, DELETE, INSERT ON DanielGoncalves.* TO 'administrador';

CREATE USER 'usuario' IDENTIFIED BY 'user';
GRANT SELECT ON DanielGoncalves.* TO 'usuario';