
-- --------            << DanielGoncalves >>        ------------ --
--                                                                   --
--                    SCRIPT DE CRIACAO (DDL)                        --
--                                                                   --
-- Data Criacao ..........: 17/10/2019                               --
-- Autor(es) .............: Daniel Maike Mendes Gonçalves            --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: DanielGoncalves                      --
--                                                                   --
-- Data Ultima Alteracao ..: 17/10/2019                              --
--    + Criacao da base de dados                                     --
--    + Criacao das tabelas                                          --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 9 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --

CREATE DATABASE IF NOT EXISTS DanielGoncalves;

USE DanielGoncalves;

CREATE TABLE PROFESSOR (
    nome VARCHAR(70) NOT NULL,
    matriculaFuncional BIGINT(11) NOT NULL,
    dtNascimento DATE NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
    CONSTRAINT PROFESSOR_PK PRIMARY KEY (matriculaFuncional)
) ENGINE = InnoDB DEFAULT CHARSET = UTF8;

CREATE TABLE DISCIPLINA (
    codigoDisciplina BIGINT(10) NOT NULL,
    sigla VARCHAR(10) NOT NULL,
    nomeCompleto VARCHAR(100) NOT NULL,
    qtdCreditos INT(3) NOT NULL,
    periodo ENUM('matutino','vespertino','noturno') NOT NULL,
    CONSTRAINT DISCIPLINA_PK PRIMARY KEY (codigoDisciplina)
) ENGINE = InnoDB DEFAULT CHARSET = UTF8;

CREATE TABLE CURSO (
    nomeCurso VARCHAR(100) NOT NULL,
    codigoCurso BIGINT(10) NOT NULL,
    classificacao ENUM('G','E') NOT NULL,
    CONSTRAINT CURSO_PK PRIMARY KEY (codigoCurso)
) ENGINE = InnoDB DEFAULT CHARSET = UTF8;

CREATE TABLE ALUNO (
    matriculaAluno BIGINT(9) NOT NULL,
    nomeCompleto VARCHAR(100) NOT NULL,
    CONSTRAINT ALUNO_PK PRIMARY KEY (matriculaAluno)
) ENGINE = InnoDB DEFAULT CHARSET = UTF8;

CREATE TABLE email (
    email VARCHAR(50) NOT NULL,
    matriculaFuncional BIGINT(11) NOT NULL,
    CONSTRAINT email_PK PRIMARY KEY (email),
    CONSTRAINT email_PROFESSOR_FK FOREIGN KEY (matriculaFuncional) REFERENCES PROFESSOR (matriculaFuncional) ON UPDATE RESTRICT ON DELETE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = UTF8;

CREATE TABLE requisita (
    codigoDisciplina BIGINT(10) NOT NULL,
    codigoDisciplinaRequisito BIGINT(10) NOT NULL,
    CONSTRAINT requisita_DISCIPLINA_FK FOREIGN KEY (codigoDisciplina) REFERENCES DISCIPLINA (codigoDisciplina) ON UPDATE RESTRICT ON DELETE RESTRICT,
    CONSTRAINT requisita_DISCIPLINA_requisito_FK FOREIGN KEY (codigoDisciplinaRequisito) REFERENCES DISCIPLINA (codigoDisciplina) ON UPDATE RESTRICT ON DELETE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = UTF8;

CREATE TABLE leciona (
    matriculaFuncional BIGINT(11) NOT NULL,
    codigoDisciplina BIGINT(10) NOT NULL,
    CONSTRAINT leciona_PROFESSOR_FK FOREIGN KEY (matriculaFuncional) REFERENCES PROFESSOR (matriculaFuncional) ON UPDATE RESTRICT ON DELETE RESTRICT,
    CONSTRAINT leciona_DISCIPLINA_FK FOREIGN KEY (codigoDisciplina) REFERENCES DISCIPLINA (codigoDisciplina) ON UPDATE RESTRICT ON DELETE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = UTF8;

CREATE TABLE formado (
    matriculaFuncional BIGINT(11) NOT NULL,
    codigoCurso BIGINT(10) NOT NULL,
    CONSTRAINT formado_PROFESSOR_FK FOREIGN KEY (matriculaFuncional) REFERENCES PROFESSOR (matriculaFuncional) ON UPDATE RESTRICT ON DELETE RESTRICT,
    CONSTRAINT formado_CURSO_FK FOREIGN KEY (codigoCurso) REFERENCES CURSO (codigoCurso) ON UPDATE RESTRICT ON DELETE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = UTF8;

CREATE TABLE matricula (
    matriculaAluno BIGINT(9) NOT NULL,
    codigoDisciplina BIGINT(10) NOT NULL,
    CONSTRAINT matricula_ALUNO_FK FOREIGN KEY (matriculaAluno) REFERENCES ALUNO (matriculaAluno) ON UPDATE RESTRICT ON DELETE RESTRICT,
    CONSTRAINT matricula_DISCIPLINA_FK FOREIGN KEY (codigoDisciplina) REFERENCES DISCIPLINA (codigoDisciplina) ON UPDATE RESTRICT ON DELETE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = UTF8;