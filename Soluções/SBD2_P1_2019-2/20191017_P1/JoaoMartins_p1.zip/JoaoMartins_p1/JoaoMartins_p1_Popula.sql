﻿-- --------     << JoaoMartins_p1 >>    ------------
--
--                    SCRIPT DE INSERCAO (DML)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: João Robson Santos Martins
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: JoaoMartins
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Insere dados
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------

USE JoaoMartins;

INSERT INTO DISCIPLINA (idDisciplina, nomeCompleto, sigla, quantidadeCreditos, periodo) VALUES
(1, 'Fundamentos de Sistemas Operacionais','FSO', 4, 'matutino'),
(2, 'Sistemas de Bancos de dados', 'SBD', 4, 'matutino');