﻿-- --------     << JoaoMartins_p1 >>    ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: João Robson Santos Martins
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: JoaoMartins
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao das tabelas e da base de dados
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------
CREATE DATABASE  IF NOT EXISTS JoaoMartins;
USE JoaoMartins;

CREATE TABLE DISCIPLINA (
    nomeCompleto VARCHAR(100) NOT NULL,
    sigla VARCHAR(10) NOT NULL,
    quantidadeCreditos INT NOT NULL,
    periodo enum('matutino', 'vespertino', 'noturno'),
    idDisciplina INT NOT NULL,
    CONSTRAINT DISCIPLINA_PK PRIMARY KEY (idDisciplina)
)ENGINE = InnoDB;

CREATE TABLE nomeProfessor (
    idNome INT NOT NULL,
    primeiroNome VARCHAR(30) NOT NULL,
    ultimoNome VARCHAR(30) NOT NULL,
    CONSTRAINT nomeProfessor_PK PRIMARY KEY (idNome)
)ENGINE = InnoDB;

CREATE TABLE PROFESSOR (
    dataNascimento DATE NOT NULL,
    sexo VARCHAR(40) NOT NULL,
    idNome INT NOT NULL,
    codProfessor INT,
    CONSTRAINT PROFESSOR_PK PRIMARY KEY (codProfessor),
    CONSTRAINT PROFESSOR_nomeProfessor_FK FOREIGN KEY (idNome) REFERENCES nomeProfessor(idNome)
)ENGINE = InnoDB;

CREATE TABLE EMAIL (
    endereco VARCHAR(50) NOT NULL,
    codProfessor INT NOT NULL,
    CONSTRAINT EMAIL_PK PRIMARY KEY (endereco),
    CONSTRAINT EMAIL_PROFESSOR_FK FOREIGN KEY(codProfessor) REFERENCES PROFESSOR(codProfessor)
)ENGINE = InnoDB;

CREATE TABLE requer (
    idDisciplina INT NOT NULL,
    idDisciplinaPreRequisito INT NOT NULL,
    CONSTRAINT requer_DISCIPLINA_FK FOREIGN KEY (idDisciplina) REFERENCES DISCIPLINA(idDisciplina),
    CONSTRAINT requer_DISCIPLINAPREREQUISITO_FK FOREIGN KEY (idDisciplinaPreRequisito) REFERENCES DISCIPLINA(idDisciplina)
)ENGINE = InnoDB;

CREATE TABLE orienta (
    codProfessor INT NOT NULL,
    idDisciplina INT NOT NULL,
    CONSTRAINT orienta_PROFESSOR_FK FOREIGN KEY (codProfessor) REFERENCES PROFESSOR(codProfessor),
    CONSTRAINT orienta_DISCIPLINA_FK FOREIGN KEY (idDisciplina) REFERENCES DISCIPLINA(idDisciplina)
)ENGINE = InnoDB;
 

