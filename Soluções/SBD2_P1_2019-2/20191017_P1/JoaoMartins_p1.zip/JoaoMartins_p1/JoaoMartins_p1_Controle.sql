﻿-- --------     << JoaoMartins_p1 >>    ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: João Robson Santos Martins
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: JoaoMartins
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao dos usuarios
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------
USE JoaoMartins;

CREATE USER 'ADMIN'@'%' IDENTIFIED BY 'admin';
CREATE USER 'PESSOA'@'%' IDENTIFIED BY 'pessoa';

GRANT ALL TO USER 'ADMIN' ON JoaoMartins.*;
GRANT SELECT TO USER 'PESSOA' ON JoaoMartins.*;