﻿-- --------     << P1VitorSantos >>     ------------
/*
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Vitor Leal dos Santos
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: P1VitorSantos
-- 
-- Data Ultima Alteracao ..:
--
-- PROJETO => 01 Base de Dados
--         => 6 Tabelas
--         => 02 Usuarios
--         => 01 Visoes
--
-- -----------------------------------------------------------------
*/

CREATE DATABASE IF NOT EXISTS P1VitorSantos;

USE P1VitorSantos;

CREATE TABLE PESSOA (
    idPessoa int(8) NOT NULL,
    primeiroNome varchar(10),
    dataNascimento date,
    apelido varchar(10),
    sexo enum('M','F'),
    ultimoNome varchar(10),
    CONSTRAINT PESSOA_PK PRIMARY KEY(idPessoa)
);

CREATE TABLE RELACIONAMENTO (
    idRelacionamento int NOT NULL,
    idOutraPessoa int,
    CONSTRAINT RELACIONAMENTO_PK PRIMARY KEY(idRelacionamento)
);

CREATE TABLE CARACTERISTICA (
    idCaracteristica int(8) NOT NULL,
    hobbie varchar(40),
    interesse varchar(40),
    CONSTRAINT CARACTERISTICA_PK PRIMARY KEY(idCaracteristica)
);

CREATE TABLE EMAIL (
    email varchar(40),
    idPessoa int(8) NOT NULL,
    idEmail int(8) NOT NULL,
    CONSTRAINT EMAIL_PK PRIMARY KEY(idEmail),
    CONSTRAINT EMAIL_PESSOA_FK FOREIGN KEY(idPessoa)
    REFERENCES PESSOA (idPessoa)
    ON DELETE RESTRICT ON UPDATE RESTRICT
);

CREATE TABLE faz (
    idPessoa int NOT NULL,
    idRelacionamento int NOT NULL,
    CONSTRAINT FAZ_PESSOA_FK FOREIGN KEY(idPessoa)
    REFERENCES PESSOA (idPessoa)
    ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT FAZ_RELACIONAMENTO_FK FOREIGN KEY(idRelacionamento)
    REFERENCES RELACIONAMENTO (idRelacionamento)
    ON DELETE RESTRICT ON UPDATE RESTRICT
);

CREATE TABLE tem (
    idPessoa int(8) NOT NULL,
    IdCaracteristica int(8) NOT NULL,
    CONSTRAINT tem_PESSOA_FK FOREIGN KEY(idPessoa)
    REFERENCES PESSOA (idPessoa)
    ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT TEM_CARACTERISTICA_FK FOREIGN KEY(idCaracteristica)
    REFERENCES CARACTERISTICA (idCaracteristica)
    ON DELETE RESTRICT ON UPDATE RESTRICT
);