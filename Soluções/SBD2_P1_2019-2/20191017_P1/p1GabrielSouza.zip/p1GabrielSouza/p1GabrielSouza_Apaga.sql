-- ---------------     << GabrielSouza >>     ----------------------
-- 
--                    SCRIPT DE CRIACAO (DCL)
-- 
-- Data Criacao ...........: 17/10/19
-- Autor(es) ..............: Gabriel Alves Soares de Souza
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: GabrielSouza
-- 
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
--         => 02 Usuarios
--         => 01 Visoes
-- 
-- -----------------------------------------------------------------

use GabrielSouza;

drop table RELACIONA;
DROP TABLE POSSUI;
DROP TABLE EMAILSADICIONAIS;
DROP TABLE CARACTERISTICA;
DROP TABLE PESSOA;
