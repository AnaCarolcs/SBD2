-- ---------------     << GabrielSouza >>     ----------------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 17/10/19
-- Autor(es) ..............: Gabriel Alves Soares de Souza
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: GabrielSouza
-- 
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
--         => 02 Usuarios
--         => 01 Visoes
-- 
-- -----------------------------------------------------------------

CREATE DATABSE IF NOT EXISTS GabrielSouza;

use GabrielSouza;

CREATE TABLE PESSOA (
emailPrincipal	varchar(30),
primeiroNome	varchar(30)	NOT NULL,
apelido		varchar(15)	NOT NULL,
sexo		enum('M','F')	NOT NULL,
dtNascimento	date		NOT NULL,
CONSTRAINT PESSOA_PK PRIMARY KEY (emailPrincipal)
);

CREATE TABLE CARACTERISTICA(
id	int,
descricao	varchar(30) NOT NULL,
CONSTRAINT CARACTERISTICA_PK PRIMARY KEY (id)
);

CREATE TABLE EMAILSADICIONAIS(
idPessoa	varchar(50) NOT NULL,
emailsAdicionais varchar(50) NOT NULL,
CONSTRAINT EMAILSADICIONAIS_PESSOA_FK FOREIGN KEY (idPessoa) REFERENCES PESSOA (emailPrincipal)
);

CREATE TABLE POSSUI(
idCaracteristica	int NOT NULL,
idPessoa		varchar(50) NOT NULL,
CONSTRAINT POSSUI_PESSOA_FK FOREIGN KEY (idPessoa) REFERENCES PESSOA (emailPrincipal),
CONSTRAINT POSSUI_CARACTERISTICA_FK FOREIGN KEY (idCaracteristica) REFERENCES CARACTERISTICA (id)
);

CREATE TABLE RELACIONA(
pessoa			varchar(50) NOT NULL,
pessoaAmiga		varchar(50) NOT NULL,
CONSTRAINT RELACIONA_PESSOA_FK FOREIGN KEY (pessoa) REFERENCES PESSOA (emailPrincipal),
CONSTRAINT RELACIONA_PESSOA_AMIGA_FK FOREIGN KEY (pessoaAmiga) REFERENCES PESSOA (emailPrincipal)
);



