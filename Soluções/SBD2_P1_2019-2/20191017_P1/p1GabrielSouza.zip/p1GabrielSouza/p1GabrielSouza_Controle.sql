-- ---------------     << GabrielSouza >>     ----------------------
-- 
--                    SCRIPT DE CRIACAO (DCL)
-- 
-- Data Criacao ...........: 17/10/19
-- Autor(es) ..............: Gabriel Alves Soares de Souza
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: GabrielSouza
-- 
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
--         => 02 Usuarios
--         => 01 Visoes
-- 
-- -----------------------------------------------------------------

use GabrielSouza;

CREATE USER 'ADMIN' IDENTIFIED BY 'ADSAS13';
CREATE USER 'PESSOA' IDENTIFIED BY 'KGKJJGJ87';
