﻿-- ------------------     Vinicius Lima P1     -------------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Vinicius Ferreira Bernardo de Lima
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: viniciusLima
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de nova tabela
--
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
--
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS viniciusLima;

USE viniciusLima;

CREATE TABLE PROFESSOR (
    primeiroNome VARCHAR(100),
    ultimoNome VARCHAR(100),
    dataNascimento DATE,
    sexo ENUM('M', 'F'),
    idProfessor INT NOT NULL AUTO_INCREMENT,

    CONSTRAINT professor_PK PRIMARY KEY (idProfessor)
)ENGINE=INNODB;

CREATE TABLE DISCIPLINA (
    nomeCompleto VARCHAR(100),
    sigla VARCHAR(40),
    quantidadeCreditos INT,
    periodo ENUM('matutino', 'vespertino', 'noturno'),
    idDisciplina INT NOT NULL AUTO_INCREMENT,

    CONSTRAINT disciplina_PK PRIMARY KEY (idDisciplina)
)ENGINE=INNODB;

CREATE TABLE email (
    idProfessor INT NOT NULL PRIMARY KEY,
    email VARCHAR(100),

    CONSTRAINT email_FK FOREIGN KEY (idProfessor) REFERENCES PROFESSOR (idProfessor) ON DELETE RESTRICT ON UPDATE RESTRICT
)ENGINE=INNODB;

CREATE TABLE requisito (
    idDisciplina INT,
    idDisciplinaPreRequisito INT,

    CONSTRAINT discplina_pai_FK FOREIGN KEY (idDisciplina) REFERENCES DISCIPLINA (idDisciplina) ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT discplina_requisito_FK FOREIGN KEY (idDisciplinaPreRequisito) REFERENCES DISCIPLINA (idDisciplina) ON DELETE RESTRICT ON UPDATE RESTRICT
)ENGINE=INNODB;

CREATE TABLE orienta (
    idProfessor INT,
    idDisciplina INT,

    CONSTRAINT orienta_professor_FK FOREIGN KEY (idProfessor) REFERENCES PROFESSOR (idProfessor) ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT orienta_disciplina_FK FOREIGN KEY (idDisciplina) REFERENCES DISCIPLINA (idDisciplina) ON DELETE RESTRICT ON UPDATE RESTRICT
)ENGINE=INNODB;