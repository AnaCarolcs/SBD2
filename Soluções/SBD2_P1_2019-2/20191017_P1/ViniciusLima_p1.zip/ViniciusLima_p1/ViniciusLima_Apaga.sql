﻿-- ------------------     Vinicius Lima P1     -------------------
--
--                    SCRIPT DE EXCLUIR (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Vinicius Ferreira Bernardo de Lima
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: viniciusLima
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Exclui tabelas sem apagar a base de dados
--
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
--
-- -----------------------------------------------------------------

USE viniciusLima;

DROP TABLE orienta;
DROP TABLE requisito;
DROP TABLE email;
DROP TABLE DISCIPLINA;
DROP TABLE PROFESSOR;