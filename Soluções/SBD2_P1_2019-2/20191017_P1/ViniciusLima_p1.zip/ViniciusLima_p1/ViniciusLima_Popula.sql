﻿-- ------------------     Vinicius Lima P1     -------------------
--
--                    SCRIPT DE MANIPULAÇÃO (DML)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Vinicius Ferreira Bernardo de Lima
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: viniciusLima
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Inserção de tuplas
--
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
--
-- -----------------------------------------------------------------

USE viniciusLima;

INSERT INTO DISCIPLINA (nomeCompleto, sigla, quantidadeCreditos, periodo) VALUES
  ('Cálculo 1', 'C1', 6, 'matutino'),
  ('Cálculo 2', 'C2', 6, 'matutino'),
  ('Cálculo 3', 'C3', 6, 'matutino');


INSERT INTO PROFESSOR (primeiroNome, ultimoNome, dataNascimento, sexo) VALUES
  ('Lindomar', 'Carvalho', '1989-11-11', 'M'),
  ('Bruno', 'Souza', '1976-10-10', 'M'),
  ('Danielle', 'Lima', '1995-09-09', 'F');

INSERT INTO email (idProfessor, email) VALUES
  (1, 'a@mail.com'),
  (2, 'b@mail.com'),
  (3, 'c@mail.com');


INSERT INTO orienta (idProfessor, idDisciplina) VALUES
  (1, 3),
  (2, 2),
  (3, 1);

INSERT INTO requisito (idDisciplina, idDisciplinaPreRequisito) VALUES
  (2, 1),
  (3, 2),
  (3, 1);