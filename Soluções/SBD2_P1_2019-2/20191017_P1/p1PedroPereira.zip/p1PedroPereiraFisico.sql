﻿
-- --------     << P1 >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Ana Maria Braga
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: pedropereira
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------

create database if not exists pedropereira;
use pedropereira;

CREATE TABLE PESSOA (
    idade INT(3) NOT NULL,
    sexo CHAR(1) NOT NULL,
    dtNascimento date NOT NULL,
    primeiroNome VARCHAR(50) NOT NULL,
    ultimoNome VARCHAR(50) NOT NULL,
    apelido VARCHAR(50) NOT NULL,
    CONSTRAINT PESSOA_PK PRIMARY KEY (primeiroNome, ultimoNome, apelido)
) ENGINE=InnoDB;

CREATE TABLE CARACTERISTICA (
    nomeCaracteristica VARCHAR(50) NOT NULL,
    descricao VARCHAR(100) NOT NULL,
    CONSTRAINT CARACTERISTICA_PK PRIMARY KEY(nomeCaracteristica)
) ENGINE=InnoDB;

CREATE TABLE INTERESSE (
    nomeInteresse VARCHAR(50) NOT NULL,
    descricao VARCHAR(100) NOT NULL,
    CONSTRAINT INTERESSE_PK PRIMARY KEY(nomeInteresse)
) ENGINE=InnoDB;

CREATE TABLE email (
    email VARCHAR(100) NOT NULL,
    primeiroNome VARCHAR(50) NOT NULL,
    ultimoNome VARCHAR(50) NOT NULL,
    apelido VARCHAR(50) NOT NULL,
    CONSTRAINT email_PK PRIMARY KEY (email, primeiroNome, ultimoNome, apelido),
    CONSTRAINT email_PESSOA_FK FOREIGN KEY(primeiroNome, ultimoNome, apelido)
        REFERENCES PESSOA(primeiroNome, ultimoNome, apelido)
        ON DELETE RESTRICT ON UPDATE RESTRICT
);

CREATE TABLE relaciona (
    primeiroNomePessoa VARCHAR(50) NOT NULL,
    ultimoNomePessoa VARCHAR(50) NOT NULL,
    apelidoPessoa VARCHAR(50) NOT NULL,
    primeiroNomeRelacionado VARCHAR(50) NOT NULL,
    ultimoNomeRelacionado VARCHAR(50) NOT NULL,
    apelidoRelacionado VARCHAR(50) NOT NULL,
    CONSTRAINT relaciona_PESSOA_FK FOREIGN KEY(primeiroNomePessoa, ultimoNomePessoa, apelidoPessoa)
      REFERENCES PESSOA(primeiroNome, ultimoNome, apelido)
      ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT relaciona_RELACIONADO_FK FOREIGN KEY(primeiroNomeRelacionado, ultimoNomeRelacionado, apelidoRelacionado)
      REFERENCES PESSOA(primeiroNome, ultimoNome, apelido)
      ON DELETE RESTRICT ON UPDATE RESTRICT
);

CREATE TABLE tem (
    primeiroNome VARCHAR(50) NOT NULL,
    ultimoNome VARCHAR(50) NOT NULL,
    apelido VARCHAR(50) NOT NULL,
    nomeCaracteristica VARCHAR(50) NOT NULL,
    CONSTRAINT tem_PESSOA_FK FOREIGN KEY(primeiroNome, ultimoNome, apelido)
      REFERENCES PESSOA(primeiroNome, ultimoNome, apelido)
       ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT tem_CARACTERISTICA_FK FOREIGN KEY(nomeCaracteristica)
      REFERENCES CARACTERISTICA(nomeCaracteristica)
      ON DELETE RESTRICT ON UPDATE RESTRICT
);

CREATE TABLE possui (
    primeiroNome VARCHAR(50) NOT NULL,
    ultimoNome VARCHAR(50) NOT NULL,
    apelido VARCHAR(50) NOT NULL,
    nomeInteresse VARCHAR(50) NOT NULL,
    CONSTRAINT possui_PESSOA_FK FOREIGN KEY(primeiroNome, ultimoNome, apelido)
      REFERENCES PESSOA(primeiroNome, ultimoNome, apelido)
       ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT possui_INTERESSE_FK FOREIGN KEY(nomeInteresse)
      REFERENCES INTERESSE(nomeInteresse)
      ON DELETE RESTRICT ON UPDATE RESTRICT
);