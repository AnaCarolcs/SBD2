﻿
-- --------     << P1 >>     ------------
--
--                    SCRIPT DE CONTROLE (DCL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Ana Maria Braga
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: pedropereira
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------

use pedropereira;

create user 'ADMIN'@localhost IDENTIFIED BY 'admin123';
GRANT ALL PRIVILEGES ON pedropereira.* to ADMIN;

create user 'PESSOA'@localhost IDENTIFIED BY 'people321';
GRANT SELECT ON pedropereira.* to PESSOA;