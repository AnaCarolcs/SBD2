﻿
-- --------     << P1 >>     ------------
--
--                    SCRIPT APAGA (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Ana Maria Braga
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: pedropereira
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------

use pedropereira;

drop table possui;
drop table tem;
drop table relaciona;
drop table email;
drop table INTERESSE;
drop table CARACTERISTICA;
drop table PESSOA;