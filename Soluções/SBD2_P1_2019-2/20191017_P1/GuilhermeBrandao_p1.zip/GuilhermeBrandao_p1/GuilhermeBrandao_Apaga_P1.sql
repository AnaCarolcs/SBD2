﻿-- --------     << guilhermebrandao >>     ------------
--
--                    SCRIPT DE APAGA (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Guilherme Siqueira Brandão
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: guilhermebrandao
--
--
-- PROJETO => 01 Base de Dados
--         => 6 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------

USE guilhermebrandao;

-- Apaga tabelas
DROP TABLE matricula;
DROP TABLE ALUNO;
DROP TABLE leciona;
DROP TABLE email;
DROP TABLE PROFESSOR;
DROP TABLE DISCIPLINA;

-- Apaga usuarios
DROP USER admin;
DROP USER pessoa;
