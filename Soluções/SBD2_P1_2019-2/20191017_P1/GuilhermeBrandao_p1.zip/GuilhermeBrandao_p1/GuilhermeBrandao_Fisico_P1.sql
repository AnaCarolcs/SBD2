﻿-- --------     << guilhermebrandao >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Guilherme Siqueira Brandão
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: guilhermebrandao
--
--
-- PROJETO => 01 Base de Dados
--         => 6 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS guilhermeBrandao;
USE guilhermebrandao;

CREATE TABLE DISCIPLINA (
    idDisciplina INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    sigla VARCHAR(3) NOT NULL,
    qtdeCreditos INT(2) NOT NULL,
    periodo ENUM('matutino', 'vespertino', 'noturno') NOT NULL,
    idDisciplina_preRequisito INT,
    CONSTRAINT DISCIPLINA_PK PRIMARY KEY (idDisciplina),
    CONSTRAINT DISCIPLINA_FK FOREIGN KEY (idDisciplina_preRequisito) REFERENCES DISCIPLINA(idDisciplina)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
)ENGINE=InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PROFESSOR (
    matriculaFuncional BIGINT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    dtNascimento DATE NOT NULL,
    sexo ENUM('Feminino', 'Masculino') NOT NULL,
    CONSTRAINT PROFESSOR_PK PRIMARY KEY (matriculaFuncional)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE email (
    matriculaFuncional BIGINT NOT NULL,
    email VARCHAR(100) NOT NULL,
    CONSTRAINT email_FK FOREIGN KEY (matriculaFuncional) REFERENCES PROFESSOR(matriculaFuncional)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
)ENGINE=InnoDB;

CREATE TABLE leciona (
    matriculaFuncional BIGINT NOT NULL,
    idDisciplina INT NOT NULL,
    CONSTRAINT leciona_PROFESSOR_FK FOREIGN KEY (matriculaFuncional) REFERENCES PROFESSOR(matriculaFuncional)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    CONSTRAINT leciona_DISCIPLINA_FK FOREIGN KEY (idDisciplina) REFERENCES DISCIPLINA(idDisciplina)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
)ENGINE=InnoDB;

CREATE TABLE ALUNO (
    nome VARCHAR(100) NOT NULL,
    matricula BIGINT NOT NULL AUTO_INCREMENT,
    dtNascimento DATE NOT NULL,
    CONSTRAINT ALUNO_PK PRIMARY KEY (matricula)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE matricula (
    idDisciplina INT NOT NULL,
    matricula BIGINT NOT NULL,
    CONSTRAINT matricula_DISCIPLINA_FK FOREIGN KEY (idDisciplina) REFERENCES DISCIPLINA(idDisciplina)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    CONSTRAINT matricula_ALUNO_FK FOREIGN KEY (matricula) REFERENCES ALUNO(matricula)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
)ENGINE=InnoDB;