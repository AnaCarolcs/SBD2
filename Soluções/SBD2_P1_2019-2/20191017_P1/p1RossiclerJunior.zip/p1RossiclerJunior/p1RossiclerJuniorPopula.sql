-- --------     << RossiclerJunior >>     ------------
-- 
--                    SCRIPT APAGA
-- 
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Rossicler Rodrigues Pires Junior
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: RossiclerJunior
-- 
-- Data Ultima Alteracao ..: 28/03/2017
--   => Criacao de nova tabela
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
-- 
-- -----------------------------------------------------------------

use RossiclerJunior;

INSERT INTO PESSOA (nome, sexo, dataNascimento) VALUES ("Rossicler Junior", "M", "1998-01-01 03:00:00");
INSERT INTO PESSOA (nome, sexo, dataNascimento) VALUES ("Pedro José", "M", "1992-06-23 02:40:00");
INSERT INTO PESSOA (nome, sexo, dataNascimento) VALUES ("Maria Leticia", "F", "1996-02-014 15:00:00");

INSERT INTO CARACTERISTICA (interesse) VALUES ("Futebol");
INSERT INTO CARACTERISTICA (interesse) VALUES ("Informatica");
INSERT INTO CARACTERISTICA (interesse) VALUES ("Culinaria");

INSERT INTO RELACIONAMENTO (idPessoa, idPessoaRelacionada) VALUES (1, 2);

INSERT INTO EMAIL (email, idPessoa) VALUES ("rossiclerjr@gmail.com", 1);
INSERT INTO EMAIL (email, idPessoa) VALUES ("pedojose@gmail.com", 2);

INSERT INTO possui (idPessoa, idCaracteristica) VALUES (1, 2);
INSERT INTO possui (idPessoa, idCaracteristica) VALUES (2, 1);