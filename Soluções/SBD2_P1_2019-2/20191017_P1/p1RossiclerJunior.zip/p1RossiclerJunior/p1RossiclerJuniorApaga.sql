-- --------     << RossiclerJunior >>     ------------
-- 
--                    SCRIPT APAGA
-- 
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Rossicler Rodrigues Pires Junior
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: RossiclerJunior
-- 
-- Data Ultima Alteracao ..: 28/03/2017
--   => Criacao de nova tabela
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
-- 
-- -----------------------------------------------------------------

use RossiclerJunior;

DROP TABLE possui;
DROP TABLE EMAIL;
DROP TABLE RELACIONAMENTO;
DROP TABLE CARACTERISTICA;
DROP TABLE PESSOA;