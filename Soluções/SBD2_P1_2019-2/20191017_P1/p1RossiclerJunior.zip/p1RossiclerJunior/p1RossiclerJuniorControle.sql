-- --------     << RossiclerJunior >>     ------------
-- 
--                    SCRIPT CONTROLE
-- 
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Rossicler Rodrigues Pires Junior
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: RossiclerJunior
-- 
-- Data Ultima Alteracao ..: 28/03/2017
--   => Criacao de nova tabela
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
-- 
-- -----------------------------------------------------------------

use RossiclerJunior;

CREATE USER 'ADMIN' IDENTIFIED BY 'ADMIN';
GRANT * *.RossiclerJunior TO 'ADMIN';

CREATE USER 'PESSOA' IDENTIFIED BY 'PESSOA';
GRANT SELECT *.RossiclerJunior TO 'PESSOA';