-- --------     << RossiclerJunior >>     ------------
-- 
--                    SCRIPT APAGA
-- 
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Rossicler Rodrigues Pires Junior
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: RossiclerJunior
-- 
-- Data Ultima Alteracao ..: 28/03/2017
--   => Criacao de nova tabela
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
-- 
-- -----------------------------------------------------------------

IF NOT EXISTS CREATE DATABASE RossiclerJunior;

use RossiclerJunior;

CREATE TABLE PESSOA (
    nome VARCHAR(50),
    sexo CHAR,
    dataNascimento DATETIME,
    idPessoa INT AUTO_INCREMENT PRIMARY KEY
)Engine=InnoDB;

CREATE TABLE CARACTERISTICA (
    idCaracteristica INT AUTO_INCREMENT PRIMARY KEY,
    interesse VARCHAR(50)
)Engine=InnoDB;

CREATE TABLE RELACIONAMENTO (
    idPessoa INT,
    idPessoaRelacionada INT,
    PRIMARY KEY (idPessoa, idPessoaRelacionada),
    CONSTRAINT FOREIGN KEY (idPessoa)
        REFERENCES PESSOA (idPessoa),
    CONSTRAINT FOREIGN KEY (idPessoaRelacionada)
        REFERENCES PESSOA (idPessoa)
);

CREATE TABLE email (
    idEmail INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100),
    idPessoa INT,
    CONSTRAINT FOREIGN KEY (idPessoa)
        REFERENCES PESSOA (idPessoa)
)Engine=InnoDB;

CREATE TABLE possui (
    idPessoa INT,
    idCaracteristica INT,
    CONSTRAINT FOREIGN KEY (idPessoa)
        REFERENCES PESSOA (idPessoa),
    CONSTRAINT FOREIGN KEY (idCaracteristica)
        REFERENCES CARACTERISTICA (idCaracteristica)
);