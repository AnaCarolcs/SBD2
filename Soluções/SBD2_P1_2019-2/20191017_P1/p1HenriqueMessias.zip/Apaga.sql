﻿-- --------     << dbEmpresa >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: HenriqueMessias
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao das instrucoes DROP
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------
USE HenriqueMessias;

DROP TABLE email;
DROP TABLE tem;
DROP TABLE CARACTERISTICA;
DROP TABLE relaciona;
DROP TABLE PESSOA;
