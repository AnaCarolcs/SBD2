﻿-- --------     << dbEmpresa >>     ------------
--
--                    SCRIPT DE MANIPULACAO (DML)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: HenriqueMessias
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao da view
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------
USE HenriqueMessias;

-- View que armazena os interesses de cada pessoa, mostrando o nome e email de cada pessoa
CREATE VIEW V_CARACTERISTICAS_PESSOAIS (nome, email, interesse) AS
SELECT p.nome, e.email, c.interesse
FROM PESSOA p, email e, CARACTERISTICA c, tem t
WHERE p.idPessoa = e.idPessoa AND c.idCaracteristica = t.idCaracteristica AND p.idPessoa = t.idPessoa;
-- Nao se faz necessario o uso de indice, ja que as pesquisas sao feitas em chaves primarias