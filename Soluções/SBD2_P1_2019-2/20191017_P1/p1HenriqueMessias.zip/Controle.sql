﻿-- --------     << dbEmpresa >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: HenriqueMessias
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao dos usuarios
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------
USE HenriqueMessias;

CREATE USER 'ADMIN'@'HenriqueMessias' IDENTIFIED BY 'Admin1234@';
GRANT ALL PRIVILEGES ON HenriqueMessias.* TO 'ADMIN'@'HenriqueMessias';

CREATE USER 'PESSOA'@'HenriqueMessias' IDENTIFIED BY '123Pessoa@123';
GRANT SELECT ON HenriqueMessias.* TO 'PESSOA'@'HenriqueMessias';