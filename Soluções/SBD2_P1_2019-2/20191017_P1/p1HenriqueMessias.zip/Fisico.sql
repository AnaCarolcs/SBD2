﻿-- --------     << dbEmpresa >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: HenriqueMessias
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao das tabelas
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS HenriqueMessias;
USE HenriqueMessias;

CREATE TABLE PESSOA (
    idPessoa INT(8) NOT NULL AUTO_INCREMENT,
    nome VARCHAR(40) NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
    dtNascimento DATE NOT NULL,
    apelido VARCHAR(20) NOT NULL,
    CONSTRAINT PESSOA_PK PRIMARY KEY(idPessoa)
)ENGINE=Innodb;

CREATE TABLE relaciona (
    idPessoaA INT(8) NOT NULL,
    idPessoaB INT(8) NOT NULL,
    CONSTRAINT relaciona_PESSOA_A_FK FOREIGN KEY(idPessoaA) REFERENCES PESSOA(idPessoa) ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT relaciona_PESSOA_B_FK FOREIGN KEY(idPessoaB) REFERENCES PESSOA(idPessoa) ON DELETE RESTRICT ON UPDATE RESTRICT
)ENGINE=Innodb;

CREATE TABLE CARACTERISTICA (
    idCaracteristica INT(5) NOT NULL AUTO_INCREMENT,
    interesse VARCHAR(30) NOT NULL,
    CONSTRAINT CARACTERISTICA_PK PRIMARY KEY(idCaracteristica)
)ENGINE=Innodb;

CREATE TABLE tem (
    idPessoa INT(8) NOT NULL,
    idCaracteristica INT(5) NOT NULL,
    CONSTRAINT tem_PESSOA_FK FOREIGN KEY(idPessoa) REFERENCES PESSOA(idPessoa) ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT tem_CARACTERISTICA_FK FOREIGN KEY(idCaracteristica) REFERENCES CARACTERISTICA(idCaracteristica) ON DELETE RESTRICT ON UPDATE RESTRICT
)ENGINE=Innodb;

CREATE TABLE email (
    email VARCHAR(40) NOT NULL,
    idPessoa INT(8) NOT NULL,
    CONSTRAINT email_PESSOA_FK FOREIGN KEY(idPessoa) REFERENCES PESSOA(idPessoa) ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT email_PK PRIMARY KEY(email)
)ENGINE=Innodb;


