﻿-- --------     << dbEmpresa >>     ------------
--
--                    SCRIPT DE MANIPULACAO (DML)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: HenriqueMessias
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao das insercoes
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------
USE HenriqueMessias;

INSERT INTO PESSOA(nome, sexo, dtNascimento, apelido) VALUES
('Lucas da Silva', 'M', '1997-05-04', 'Lukinha'),
('Maria de Souza', 'F', '1987-09-02', 'MariaMaria'),
('Pedro de Lira', 'M', '1995-03-03', 'Pedroka');

INSERT INTO relaciona(idPessoaA, idPessoaB) VALUES
(1, 2),
(1, 3),
(2, 3);

INSERT INTO CARACTERISTICA(interesse) VALUES
('Ler'),
('Jogar videogame'),
('Praticar esporte');

INSERT INTO tem(idPessoa, idCaracteristica) VALUES
(3, 2),
(1, 3),
(2, 2);

INSERT INTO email(email, idPessoa) VALUES
('Lukinha@gmail.com', 1),
('MariaS@hotmail.com', 2),
('Pedroka03@gmail.com', 3);