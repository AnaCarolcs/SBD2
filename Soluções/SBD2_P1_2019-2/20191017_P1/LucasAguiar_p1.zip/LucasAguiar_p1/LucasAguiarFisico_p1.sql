﻿-- --------     << p1 >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Lucas Maciel Aguiar
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: lucasAguiar
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao das tabelas
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------

create database if not exists lucasAguiar;

CREATE TABLE PROFESSOR (
    matriculaFuncional INT PRIMARY KEY,
    nome VARCHAR(50),
    dtNascimento DATE,
    sexo ENUM('M', 'F')
)engine = InnoDb ;

CREATE TABLE email (
    matriculaFuncional INT NOT NULL PRIMARY KEY,
    email VARCHAR(50),
  CONSTRAINT FK_email_2
    FOREIGN KEY (matriculaFuncional)
    REFERENCES PROFESSOR (matriculaFuncional)
) engine = InnoDb;



CREATE TABLE DISCIPLINA (
    idDisciplina INT PRIMARY KEY auto_increment,
    nome VARCHAR(50),
    sigla VARCHAR(5),
    qtdCreditos INT,
    periodo ENUM('M', 'V', 'N')
)engine = InnoDb auto_increment = 1;

CREATE TABLE orienta (
    matriculaFuncional INT,
    idDisciplina INT,
  CONSTRAINT FK_orienta_1
    FOREIGN KEY (matriculaFuncional)
    REFERENCES PROFESSOR (matriculaFuncional)
    ON DELETE RESTRICT
)engine = InnoDb ;

CREATE TABLE depende (
    idDisciplina INT,
    idDisciplinaDependente INT,
  CONSTRAINT FK_depende_1
    FOREIGN KEY (idDisciplina)
    REFERENCES DISCIPLINA (idDisciplina)
    ON DELETE RESTRICT,
  CONSTRAINT FK_depende_2
    FOREIGN KEY (idDisciplinaDependente)
    REFERENCES DISCIPLINA (idDisciplina)
    ON DELETE RESTRICT
)engine = InnoDb ;


CREATE TABLE CURSO (
    idCurso INT PRIMARY KEY auto_increment,
    nomeCurso VARCHAR(50),
    classificacao VARCHAR(20)
)engine = InnoDb auto_increment = 1;

CREATE TABLE formado (
    idDisciplina INT,
    idCurso INT,
  CONSTRAINT FK_formado_1
    FOREIGN KEY (idDisciplina)
    REFERENCES DISCIPLINA (idDisciplina)
    ON DELETE RESTRICT
)engine = InnoDb ;

