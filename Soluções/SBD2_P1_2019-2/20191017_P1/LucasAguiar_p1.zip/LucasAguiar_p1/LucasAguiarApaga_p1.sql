﻿-- --------     << p1 >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Lucas Maciel Aguiar
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: lucasAguiar
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao das tabelas
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------

use lucasAguiar;

drop table depende;
drop table formado;
drop table email;
drop table orienta;
drop table CURSO;
drop table DISCIPLINA;
drop table PROFESSOR;