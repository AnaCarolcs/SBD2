﻿-- --------     << p1 >>     ------------
--
--                    SCRIPT DE CONTROLE ()
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Lucas Maciel Aguiar
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: lucasAguiar
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao das tabelas
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------

-- Usuario Aministrador
create user 'ADMIN' identified by 'admin1234';
grant all privileges on lucasAguiar.* to 'ADMIN';

-- Usuario Pessoa
create user 'PESSOA' identified by 'pessoa1234';
grant select on lucasAguiar.* to 'PESSOA';