﻿-- --------     << p1 >>     ------------
--
--                    SCRIPT DE BUSCA (DML)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Lucas Maciel Aguiar
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: lucasAguiar
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao das tabelas
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------


-- Listar todas as disciplinas ministradas por cada professor
-- seria relevante para conseguir mapear as disciplinas de cada professor
create or replace view V_PROFESSOR_DISCIPLINA (professor, disciplina) as
select (p.nome, d.nome)
from PROFESSOR p
inner join orienta o on (p.matriculaFuncional = o.matriculaFuncional)
inner join DISCIPLINA d (o.idDisciplina = d.idDisciplina)
order by p.nome;