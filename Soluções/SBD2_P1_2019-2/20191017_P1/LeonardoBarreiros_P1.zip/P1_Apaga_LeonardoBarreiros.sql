﻿-- --------     << Prova 1 >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Ana Maria Braga
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: prova1
-- 
-- Data Ultima Alteracao ..: 28/03/2017
--   => Criacao de nova tabela
--
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
--
--
--
--
-- -----------------------------------------------------------------

USE prova1;

DROP TABLE apto;
DROP TABLE requer;
DROP TABLE cadastra;
DROP TABLE DISCIPLINA;
DROP TABLE PROFESSOR;
DROP TABLE ALUNO;