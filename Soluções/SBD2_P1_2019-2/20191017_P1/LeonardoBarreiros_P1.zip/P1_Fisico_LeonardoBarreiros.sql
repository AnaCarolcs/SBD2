﻿-- --------     << Prova 1 >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Ana Maria Braga
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: prova1
-- 
-- Data Ultima Alteracao ..: 28/03/2017
--   => Criacao de nova tabela
-- 
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
--
--
--
--
-- -----------------------------------------------------------------

CREATE DATABASE prova1;

USE prova1;

CREATE TABLE ALUNO(
  matricula INT NOT NULL,
  nome VARCHAR(20) NOT NULL,

  CONSTRAINT ALUNO_PK PRIMARY KEY(matricula)
)ENGINE = InnoDB;

CREATE TABLE PROFESSOR(
  cpf BIGINT NOT NULL,
  nome VARCHAR(20) NOT NULL,
  sobrenome VARCHAR(50) NOT NULL,
  dtNascimento DATE NOT NULL,
  sexo ENUM('M', 'F') NOT NULL,

  CONSTRAINT PROFESSOR_PK PRIMARY KEY(cpf)
)ENGINE = InnoDB;

CREATE TABLE DISCIPLINA(
  codigo INT NOT NULL,
  nomeCompleto VARCHAR(50) NOT NULL,
  sigla VARCHAR(10) NOT NULL,
  qtdCredtido INT NOT NULL,
  periodo ENUM('matutino', 'vespertino', 'noturno'),

  CONSTRAINT DISCIPLINA_PK PRIMARY KEY(codigo)
)ENGINE =InnoDB;

CREATE TABLE cadastra(
  matricula INT NOT NULL,
  codigo INT NOT NULL,

  CONSTRAINT cadastra_ALUNO_FK FOREIGN KEY(matricula) REFERENCES ALUNO(matricula),
  CONSTRAINT cadastra_DISCIPLINA_FK FOREIGN KEY(codigo) REFERENCES DISCIPLINA(codigo)
)ENGINE = InnoDB;

CREATE TABLE requer(
  idRequisito INT NOT NULL,
  codigo INT NOT NULL,

  CONSTRAINT requer_PK PRIMARY KEY(idRequisito),
  CONSTRAINT requer_DISCIPLINA_FK FOREIGN KEY(codigo) REFERENCES DISCIPLINA(codigo)
)ENGINE = InnoDB;

CREATE TABLE apto(
  cpf BIGINT NOT NULL,
  codigo INT NOT NULL,

  CONSTRAINT apto_PROFESSOR_FK FOREIGN KEY(cpf) REFERENCES PROFESSOR(cpf),
  CONSTRAINT apto_DISCIPLINA_FK FOREIGN KEY(codigo) REFERENCES DISCIPLINA(codigo)
)ENGINE = InnoDB;