﻿-- --------     << Prova 1 >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Leonardo Barreiros
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: prova1
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de nova tabela
--
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
--
--         => criando script de controle
--
--
-- -----------------------------------------------------------------


CREATE USER 'ADMIN' IDENTIFIED BY 'ADMIN';
GRANT ALL PRIVILEGES ON prova1.* TO 'ADMIN';

CREATE USER 'PESSOA' IDENTIFIED BY 'PESSOA';
GRANT SELECT ON prova1.* TO 'PESSOA';
