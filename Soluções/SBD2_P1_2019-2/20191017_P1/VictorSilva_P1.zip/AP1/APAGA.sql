﻿-- --------     Disciplinas   ------------
--
--                    SCRIPT DE APAGA (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Victor Rodrigues Silva
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: victorSilva
--
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------

USE victorSilva;

DROP TABLE possui;
DROP TABLE leciona;
DROP TABLE PROFESSOR;
DROP TABLE PREREQUISITO;
DROP TABLE DISCIPLINA;
DROP TABLE PERIODO;
DROP TABLE email;