﻿-- --------     Disciplinas   ------------
--
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Victor Rodrigues Silva
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: victorSilva
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao da base de dados
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS victorSilva;

USE victorSilva;


CREATE TABLE PREREQUISITO (
    idPrerequisito BIGINT,
    disciplina BIGINT,

    CONSTRAINT PREREQUISITO_PK PRIMARY KEY(idPrerequisito)
)ENGINE = InnoDB;

CREATE TABLE PERIODO (
    idPeriodo BIGINT,
    turno VARCHAR(50),

    CONSTRAINT PERIODO_PK PRIMARY KEY(idPeriodo)
)ENGINE = InnoDB;

CREATE TABLE DISCIPLINA (
    matriculaDisciplina BIGINT,
    nome VARCHAR(50),
    sigla VARCHAR(10),
    creditos INT,
    periodo BIGINT,
    idPeriodo BIGINT,

    CONSTRAINT DISCIPLINA_PK PRIMARY KEY(matriculaDisciplina),
    CONSTRAINT DISCIPLINA_PERIODO_FK FOREIGN KEY (idPeriodo)
      REFERENCES PERIODO (idPeriodo)
      ON DELETE RESTRICT
)ENGINE = InnoDB;


CREATE TABLE email (
    idEmail INT NOT NULL,
    email VARCHAR(100),

    CONSTRAINT email_PK PRIMARY KEY(idEmail)
)ENGINE = InnoDB;

CREATE TABLE PROFESSOR (
    matriculaProfessor BIGINT,
    nome VARCHAR(100),
    dtNascimento DATE,
    sexo enum('M', 'F'),
    idade INT,
    email INT,

    CONSTRAINT PROFESSOR_PK PRIMARY KEY(matriculaProfessor),
    CONSTRAINT PROFESSOR_email_FK
      FOREIGN KEY (email)
      REFERENCES email (idEmail)
)ENGINE = InnoDB;



CREATE TABLE leciona (
    matriculaProfessor BIGINT,
    matriculaDisciplina BIGINT,

    CONSTRAINT leciona_professor_FK FOREIGN KEY (matriculaProfessor)
      REFERENCES PROFESSOR (matriculaProfessor)
      ON DELETE RESTRICT,
    CONSTRAINT leciona_DISCIPLINA_FK
      FOREIGN KEY (matriculaDisciplina)
      REFERENCES DISCIPLINA (matriculaDisciplina)
      ON DELETE RESTRICT
)ENGINE = InnoDB;

CREATE TABLE possui (
    matriculaDisciplina BIGINT,
    idPrerequisito BIGINT,

    CONSTRAINT possui_disciplina_FK
      FOREIGN KEY (matriculaDisciplina)
      REFERENCES DISCIPLINA (matriculaDisciplina)
      ON DELETE RESTRICT,
    CONSTRAINT possui_prerequisito_FK
      FOREIGN KEY (idPrerequisito)
      REFERENCES PREREQUISITO (idPrerequisito)
)ENGINE = InnoDB;