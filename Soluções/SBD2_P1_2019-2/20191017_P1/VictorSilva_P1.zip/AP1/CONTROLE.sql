﻿-- --------     Disciplinas   ------------
--
--                    SCRIPT DE CONTROLE (DML)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Victor Rodrigues Silva
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: victorSilva
--
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------

CREATE USER 'ADMIN'@'localhost' IDENTIFIED BY 'senhaAdmin';
GRANT ALL PRIVILEGES ON victorSilva.* TO ADMIN ;

CREATE USER 'PESSOA'@'localhost' IDENTIFIED BY 'senhaPessoa';
GRANT SELECT ON victorSilva.* TO PESSOA;