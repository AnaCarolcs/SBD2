-- --------     << Pessoas Relacionadas >>     ------------
-- 
--                    SCRIPT DE POPULA(DML)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Andre Lucas de Sousa Pinto 17/0068251
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: andrepinto
-- 
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
-- 
-- -----------------------------------------------------------------

USE andrepinto;

INSERT INTO PESSOA VALUES ('1990-10-10', 'M', 'Joaquin', 'JoJo', 'Silva', NULL);
INSERT INTO PESSOA VALUES ('1990-11-10', 'M', 'Adriano', 'Ade', 'Silva', NULL);
INSERT INTO PESSOA VALUES ('1990-12-10', 'M', 'Eduardo', 'Dudu', 'Silva', NULL);

INSERT INTO CARACTERISTICA VALUES (NULL, 'Jogar Bola');
INSERT INTO CARACTERISTICA VALUES (NULL, 'Dancas');
INSERT INTO CARACTERISTICA VALUES (NULL, 'Codar');

INSERT INTO email VALUES (1, 'jojo@gmail.com');
INSERT INTO email VALUES (1, 'jojo2@gmail.com');
INSERT INTO email VALUES (1, 'jojo3@gmail.com');

INSERT INTO relaciona (1, 2);
INSERT INTO relaciona (1, 3);
INSERT INTO relaciona (2, 3);

INSERT INTO possui VALUES (1, 1);
INSERT INTO possui VALUES (2, 1);
INSERT INTO possui VALUES (3, 1);