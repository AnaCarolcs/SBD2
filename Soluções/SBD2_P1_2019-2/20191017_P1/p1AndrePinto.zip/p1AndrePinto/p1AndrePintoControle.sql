-- --------     << Pessoas Relacionadas >>     ------------
-- 
--                    SCRIPT DE CONTROLE(DDL)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Andre Lucas de Sousa Pinto 17/0068251
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: andrepinto
-- 
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
-- 
-- -----------------------------------------------------------------

USE andrepinto;

CREATE USER 'ADMIN' IDENTIFIED BY 'AwesomePassword123';
GRANT ALL PRIVILEGES ON andrepinto.* TO 'ADMIN';

CREATE USER 'PESSOA' IDENTIFIED BY 'AwesomePassword456';
GRANT SELECT ON andrepinto.* TO 'PESSOA';