-- --------     << Pessoas Relacionadas >>     ------------
-- 
--                    SCRIPT DE APAGA(DDL)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Andre Lucas de Sousa Pinto 17/0068251
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: andrepinto
-- 
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
-- 
-- -----------------------------------------------------------------

USE andrepinto;

DROP TABLE possui;
DROP TABLE relaciona;
DROP TABLE email;
DROP TABLE CARACTERISTICA;
DROP TABLE PESSOA;