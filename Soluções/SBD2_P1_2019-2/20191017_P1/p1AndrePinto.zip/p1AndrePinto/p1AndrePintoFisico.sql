-- --------     << Pessoas Relacionadas >>     ------------
-- 
--                    SCRIPT FISICO(DDL)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Andre Lucas de Sousa Pinto 17/0068251
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: andrepinto
-- 
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
-- 
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS andrepinto;

USE andrepinto;

CREATE TABLE PESSOA (
    dtNascimento DATE NOT NULL,
    sexo ENUM('M','F') NOT NULL,
    primeiroNome VARCHAR(50) NOT NULL,
    apelido VARCHAR(50) NOT NULL,
    ultimoNome VARCHAR(50) NOT NULL,
    idPessoa INT NOT NULL AUTO_INCREMENT,
    CONSTRAINT PESSOA_PK PRIMARY KEY (idPessoa)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE CARACTERISTICA (
    codigo INT NOT NULL AUTO_INCREMENT,
    caracteristica VARCHAR(50) NOT NULL,
    CONSTRAINT CARACTERISTICA_PK PRIMARY KEY (codigo)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE email (
    idPessoa INT NOT NULL,
    email VARCHAR(100) NOT NULL,
    CONSTRAINT email_PK PRIMARY KEY (idPessoa, email),
    CONSTRAINT PESSOA_email_FK FOREIGN KEY (idPessoa) REFERENCES PESSOA (idPessoa) ON UPDATE RESTRICT ON DELETE RESTRICT
) ENGINE = InnoDB;

CREATE TABLE relaciona (
    idPessoa1 INT NOT NULL,
    idPessoa2 INT NOT NULL,
    CONSTRAINT PESSOA_PESSOA1_FK FOREIGN KEY (idPessoa1) REFERENCES PESSOA (idPessoa) ON UPDATE RESTRICT ON DELETE RESTRICT,
    CONSTRAINT PESSOA_PESSOA2_FK FOREIGN KEY (idPessoa2) REFERENCES PESSOA (idPessoa) ON UPDATE RESTRICT ON DELETE RESTRICT
) ENGINE = InnoDB;

CREATE TABLE possui (
    idPessoa INT NOT NULL,
    codigo INT NOT NULL,
    CONSTRAINT possui_PK PRIMARY KEY (codigo),
    CONSTRAINT PESSOA_possui_FK FOREIGN KEY (idPessoa) REFERENCES PESSOA (idPessoa) ON UPDATE RESTRICT ON DELETE RESTRICT,
    CONSTRAINT CARACTERISTCA_possui_FK FOREIGN KEY (codigo) REFERENCES CARACTERISTICA (codigo) ON UPDATE RESTRICT ON DELETE RESTRICT
) ENGINE = InnoDB;