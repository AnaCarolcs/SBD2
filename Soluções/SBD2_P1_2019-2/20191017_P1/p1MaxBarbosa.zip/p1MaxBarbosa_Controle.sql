﻿-- --------                 << p1Pessoa  >>             ------------
--
--                    SCRIPT DE CONTROLE (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Max Henrique Barbosa
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: p1Pessoa
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => adiciona dois usuarios e concede permissoes
--
-- PROJETO => 01 Base de Dados
--         => 03 Tabelas
--         => 02 Sequencias
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------

USE p1Pessoa;

CREATE USER 'ADMIN' IDENTIFIED BY 'senha1';

CREATE USER 'PESSOA' IDENTIFIED BY 'senha2';


GRANT ALL PRIVILEGES ON p1Pessoa.* TO 'ADMIN';

GRANT SELECT ON p1Pessoa.* TO  'PESSOA';
