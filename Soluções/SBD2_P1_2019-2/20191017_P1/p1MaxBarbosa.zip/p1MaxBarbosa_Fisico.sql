﻿-- --------                 << p1Pessoa  >>             ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Max Henrique Barbosa
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: p1Pessoa
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de nova base de dados e criacao das tabelas
--
-- PROJETO => 01 Base de Dados
--         => 03 Tabelas
--         => 02 Sequencias
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------

CREATE DATABASE if not exists  p1Pessoa;

USE p1Pessoa;

CREATE TABLE if not exists CARACTERISTICA (
    idCaracteristica BIGINT NOT NULL AUTO_INCREMENT,
    descCaracteristica VARCHAR (50),

CONSTRAINT CARACTERISTICA_PK PRIMARY KEY (idCaracteristica)
)ENGINE = InnoDB AUTO_INCREMENT = 0;

CREATE TABLE if not exists PESSOA (
    primeiroNome VARCHAR(30) NOT NULL,
    ultimoNome VARCHAR(30) NOT NULL,
    apelido VARCHAR(30),
    dataNasc DATE NOT NULL,
    sexo CHAR check('M' or 'F'),
    email VARCHAR(50) UNIQUE,
    idCaracteristica bigint NOT NULL,
    idPessoa BIGINT AUTO_INCREMENT,

CONSTRAINT PESSOA_PK PRIMARY KEY (idPessoa),
CONSTRAINT PESSOA_CARACTERISTICA_FK FOREIGN KEY (idCaracteristica) REFERENCES CARACTERISTICA (idCaracteristica)
           ON DELETE RESTRICT
           ON UPDATE RESTRICT
)ENGINE = InnoDB AUTO_INCREMENT = 0;

CREATE TABLE if not exists RELACIONAMENTO (
    primeiroNome VARCHAR(30) NOT NULL,
    ultimoNome VARCHAR(30) NOT NULL,
    apelido VARCHAR(30),
    codOutra BIGINT NOT NULL,
    idPessoa BIGINT NOT NULL,

    CONSTRAINT RELACIONAMENTO_PK PRIMARY KEY (codOutra),
    CONSTRAINT RELACIONAMENTO_PESSOA_FK FOREIGN KEY (idPessoa) REFERENCES PESSOA (idPessoa)
           ON DELETE RESTRICT
           ON UPDATE RESTRICT
)ENGINE = InnoDB;

