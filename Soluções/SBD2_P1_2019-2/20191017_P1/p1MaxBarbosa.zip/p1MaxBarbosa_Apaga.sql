﻿-- --------                 << p1Pessoa  >>             ------------
--
--                    SCRIPT DE REMOCAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Max Henrique Barbosa
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: p1Pessoa
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => apaga as tabelas
--
-- PROJETO => 01 Base de Dados
--         => 03 Tabelas
--         => 02 Sequencias
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------


USE p1Pessoa;

DROP TABLE if exists RELACIONAMENTO;
DROP TABLE if exists PESSOA;
DROP TABLE if exists CARACTERISTICA;
