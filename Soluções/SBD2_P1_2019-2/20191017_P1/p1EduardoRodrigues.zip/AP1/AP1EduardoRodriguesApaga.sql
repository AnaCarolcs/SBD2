﻿-- --------     << EduardoRodrigues >>     ------------
--
--                    SCRIPT APAGA (DDL)
--
-- Data Criacao ...........: 17/10/2018
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: EduardoRodrigues
--
-- Data Ultima Alteracao ..: 17/10/2017
--   => Apaga tabelas sem apagar base, apaga usuarios e views
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------

use EduardoRodrigues;

drop table possui;
drop table relaciona;
drop table email;
drop table CARACTERISTICA;
drop table PESSOA;


DROP USER ADMIN;
DROP USER PESSOA;