﻿-- --------     << EduardoRodrigues >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL/DCL)
--
-- Data Criacao ...........: 17/10/2018
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: EduardoRodrigues
--
-- Data Ultima Alteracao ..: 17/10/2017
--   => Criacao de usuario
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------

use EduardoRodrigues;

CREATE USER 'ADMIN' IDENTIFIED BY 'ADMIN';
GRANT ALL PRIVILEGES ON EduardoRodrigues.* TO ADMIN;

CREATE USER 'PESSOA' IDENTIFIED BY 'PESSOA';
GRANT SELECT, UPDATE, DELETE ON EduardoRodrigues.* TO PESSOA;