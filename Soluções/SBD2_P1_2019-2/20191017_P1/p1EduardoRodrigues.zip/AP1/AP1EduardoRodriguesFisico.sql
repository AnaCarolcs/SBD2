﻿-- --------     << EduardoRodrigues >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2018
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: EduardoRodrigues
--
-- Data Ultima Alteracao ..: 17/10/2017
--   => Criacao de base de dados e tabelas
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS EduardoRodrigues;

use EduardoRodrigues;

CREATE TABLE PESSOA (
    cpf bigint(11) NOT NULL,
    nome varchar(30) NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
    dtNasc DATE NOT NULL,
    apelido varchar(20) NOT NULL,
    constraint PESSOA_PK PRIMARY KEY (cpf)
)engine=InnoDb;

CREATE TABLE CARACTERISTICA (
    codCaracteristica int NOT NULL auto_increment,
    nomeCaracteristica varchar(30) NOT NULL,
    descCaracteristica varchar(100) NOT NULL,
    constraint CARACTERISTICA_PK PRIMARY KEY (codCaracteristica),
    CONSTRAINT CARACTERISTICA_UK UNIQUE (nomeCaracteristica)
)engine=InnoDb auto_increment=1;

CREATE TABLE email (
    cpf bigint(11) NOT NULL,
    email varchar(30) not null,
    constraint email_fk foreign key (cpf) references PESSOA(cpf)
      on delete restrict
      on update restrict,
    constraint email_uk unique (email)
)engine=InnoDb;

CREATE TABLE relaciona (
    cpfPessoa bigint(11) not null,
    cpf bigint(11) not null,
    constraint relaciona_pessoa_FK foreign key (cpfPessoa) references PESSOA(cpf)
      on delete restrict
      on update restrict,
    constraint relaciona_pessoa_pessoa_FK foreign key (cpf) references PESSOA(cpf)
      on delete restrict
      on update restrict,
    constraint relaciona_UK UNIQUE (cpfPessoa, cpf)
)engine=InnoDb;

CREATE TABLE possui (
    cpf bigint(11) not null,
    codCaracteristica int not null,
    constraint possui_PESSOA_FK foreign key (cpf) references PESSOA(cpf)
      on delete restrict
      on update restrict,
    constraint possui_CARACTERISTICA_FK foreign key (codCaracteristica) references CARACTERISTICA(codCaracteristica)
      on delete restrict
      on update restrict,
    constraint possui_UK UNIQUE (cpf, codCaracteristica)
)engine=innodb;
