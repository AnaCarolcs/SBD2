﻿-- --------     << Pessoa >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Lieverton Santos Silva
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: lievertonsilva
--
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS lievertonsilva;

USE lievertonsilva;

CREATE TABLE PESSOA (
    idPessoa INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(50) NOT NULL,
    apelido VARCHAR(50) NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
    dtNascimento DATE NOT NULL,
    CONSTRAINT PESSOA_PK PRIMARY KEY (idPessoa)
) ENGINE InnoDB DEFAULT CHARSET UTF8 AUTO_INCREMENT = 1;

CREATE TABLE CARACTERISTICA (
    codCaracteristica INT NOT NULL AUTO_INCREMENT,
    nomeCaracteristica VARCHAR(100) NOT NULL,
    tipoCaracteristica ENUM('PESSOAL', 'INTERESSE') NOT NULL,
    CONSTRAINT CARACTERISTICA_PK PRIMARY KEY (codCaracteristica)
) ENGINE InnoDB DEFAULT CHARSET UTF8 AUTO_INCREMENT = 1;

CREATE TABLE email (
    idPessoa INT NOT NULL,
    email VARCHAR(100) NOT NULL,
    CONSTRAINT email_PK PRIMARY KEY (email),
    CONSTRAINT email_PESSOA_FK FOREIGN KEY (idPessoa)
        REFERENCES PESSOA (idPessoa)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE InnoDB DEFAULT CHARSET UTF8;

CREATE TABLE segue (
    idPessoa INT NOT NULL,
    idPessoaSeguida INT NOT NULL,
    CONSTRAINT segue_PK PRIMARY KEY (idPessoa, idPessoaSeguida),
    CONSTRAINT segue_PESSOA_FK FOREIGN KEY (idPessoa)
        REFERENCES PESSOA (idPessoa)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT segue_PESSOA2_FK FOREIGN KEY (idPessoaSeguida)
        REFERENCES PESSOA (idPessoa)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE InnoDB DEFAULT CHARSET UTF8;

CREATE TABLE possui (
    idPessoa INT NOT NULL,
    codCaracteristica INT NOT NULL,
    CONSTRAINT possui_PK PRIMARY KEY (idPessoa, codCaracteristica),
    CONSTRAINT possui_PESSOA_FK FOREIGN KEY (idPessoa)
        REFERENCES PESSOA (idPessoa)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE InnoDB DEFAULT CHARSET UTF8;