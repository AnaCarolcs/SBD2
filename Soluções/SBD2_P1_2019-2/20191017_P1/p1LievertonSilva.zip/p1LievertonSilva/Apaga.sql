﻿-- --------     << Pessoa >>     ------------
--
--                    SCRIPT APAGA (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Lieverton Santos Silva
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: lievertonsilva
--
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------

USE lievertonsilva;

DROP TABLE possui;
DROP TABLE segue;
DROP TABLE email;
DROP TABLE CARACTERISTICA;
DROP TABLE PESSOA;