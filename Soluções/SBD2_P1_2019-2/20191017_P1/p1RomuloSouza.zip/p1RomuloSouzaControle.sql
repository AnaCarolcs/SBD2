-- --------     << p1RomuloSouza >>     ------------
-- 
--                    SCRIPT DE CONTROLE DE ACESSO (DDL)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: R�mulo Vin�cius de Souza
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: RomuloSouza
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao usuarios admin e pessoa
-- 
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
--         => 02 Usuarios
-- 
-- -----------------------------------------------------------------



CREATE USER 'admin'@'localhost' IDENTIFIED BY 'admin123';
GRANT ALL PRIVILEGES ON RomuloSouza.* TO 'admin'@'localhost';

CREATE USER 'pessoa'@'localhost' IDENTIFIED BY 'pessoa123';
GRANT SELECT, UPDATE, DELETE on RomuloSouza.* TO 'pessoa'@'localhost';