-- --------     << p1RomuloSouza >>     ------------
-- 
--                    SCRIPT DE DELECAO(DDL)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: R�mulo Vin�cius de Souza
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: RomuloSouza
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de tabelas
-- 
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
--         => 02 Usuarios
-- 
-- -----------------------------------------------------------------

use RomuloSouza;

drop table tem;
drop table relaciona;
drop table email;
drop table caracteristica;
drop table pessoa;
