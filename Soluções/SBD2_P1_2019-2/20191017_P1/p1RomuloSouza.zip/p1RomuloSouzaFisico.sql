-- --------     << p1RomuloSouza >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: R�mulo Vin�cius de Souza
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: RomuloSouza
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de tabelas
-- 
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
--         => 02 Usuarios
-- 
-- -----------------------------------------------------------------


CREATE DATABASE IF NOT EXISTS RomuloSouza;

use RomuloSouza;

CREATE TABLE PESSOA (
    idPessoa INT AUTO_INCREMENT,
    nomePessoa VARCHAR(200) NOT NULL,
    sexo enum('M','F') NOT NULL,
    dtNascimento DATE NOT NULL,

   constraint PESSOA_PK primary key (idPessoa)
)Engine = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8;

CREATE TABLE CARACTERISTICA (
    idCaracteristica INT AUTO_INCREMENT,
    hobby VARCHAR(500) NOT NULL,
    nomeCaracteristica VARCHAR(100) NOT NULL,
   constraint CARACTERISTICA_PK primary key (idPessoa)
) Engine = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8;

CREATE TABLE email (
    email VARCHAR(100) NOT NULL,
    pessoa INT NOT NULL,

    constraint email_PESSOA_FK (pessoa) REFERENCES PESSOA (idPessoa)
) Engine = InnoDB DEFAULT CHARSET = utf8;

CREATE TABLE relaciona (
    pessoaOrigem INT,
    pessoaDestino INT,
    constraint relaciona_PESSOA_origem_FK (pessoaOrigem) references PESSOA (idPessoa),
    constraint relaciona_PESSOA_destino_FK (pessoaDestino) references PESSOa (idPessoa)
) Engine = InnoDB DEFAULT CHARSET = utf8;

CREATE TABLE tem (
    pessoa INT NOT NULL,
    caracteristica INT NOT NULL,
    constraint tem_PESSOA_FK (pessoa) references PESSOA (idPessoa),
    constraint tem_CARACTERISTICA_FK (caracteristica) references CARACTERISTICA (idCaracteristica)
) Engine = InnoDB DEFAULT CHARSET = utf8;
