-- --------     << p1RomuloSouza >>     ------------
-- 
--                    SCRIPT DE POPULACAO(DML)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: R�mulo Vin�cius de Souza
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: RomuloSouza
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de tabelas
-- 
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
--         => 02 Usuarios
-- 
-- -----------------------------------------------------------------

use RomuloSouza;

insert into pessoa (nomePessoa, sexo, dtNascimento) VALUES ('Jose Silva', 'M', '2000-10-10);
insert into pessoa  (nomePessoa, sexo, dtNascimento) VALUES ('Caio Costa ', 'M', '2000-10-10);
insert into pessoa  (nomePessoa, sexo, dtNascimento) VALUES ('Jose Fagundes', 'M', '2001-10-10);

insert into caracteristica (hobby, nomeCaracteristica) VALUES ('Problemas com pcs na FGA', 'PROBLEMAS INFRA');
