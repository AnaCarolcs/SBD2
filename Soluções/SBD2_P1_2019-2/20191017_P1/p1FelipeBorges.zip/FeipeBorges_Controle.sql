﻿-- --------     << FelipeChaves >>     ------------
--
--                    SCRIPT DE CRIACAO (DDl)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Felipe Borges de Souza Chaves
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: FelipeChaves
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao do script fisico inicial
--
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
--         => 02 Usuarios
--         => 01 Visoes
--
-- -----------------------------------------------------------------

USE P1Felipechaves;


-- usuário com permissão de administrar a base de dados.
CREATE USER "admin@localhost" IDENTIFIED BY "admin123";
GRANT ALL PRIVILEGES ON P1FelipeChaves.* TO admin WITH GRANT OPTION;


-- pessoa com acessso de leitura a toda base representando um usuário
CREATE USER "pessoa@locahost" IDENTIFIED BY "pessoa123";
GRANT SELECT ON P1FelipeChaves.* TO pessoa;