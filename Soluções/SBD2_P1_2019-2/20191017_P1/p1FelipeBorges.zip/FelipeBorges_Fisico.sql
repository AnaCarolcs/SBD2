﻿-- --------     << FelipeChaves >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Felipe Borges de Souza Chaves
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: FelipeChaves
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao do script fisico inicial
--
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
--         => 02 Sequencias
--         => 03 Usuarios
--         => 02 Visoes
--
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS P1FelipeChaves;

USE P1FelipeChaves;

CREATE TABLE PESSOA(
  emailConta         VARCHAR(100)    NOT NULL,
  sexo               ENUM("M", "F")  NOT NULL,
  primeiroNome       VARCHAR(50)     NOT NULL,
  ultimoNome         VARCHAR(50)     NOT NULL,
  apelido            VARCHAR(50)     NOT NULL,
  dataNascimento     DATE            NOT NULL,

  CONSTRAINT PESSOA_PK PRIMARY KEY(emailConta)

)ENGINE=InnoDB;

CREATE TABLE CARACTERISTICA(
  idCaracteristica   INT             NOT NULL,
  interesse          VARCHAR(200)    NOT NULL,

  CONSTRAINT CARACTERISTICA_PK PRIMARY KEY(idCaracteristica)
)ENGINE=InnoDB;

CREATE TABLE email(
  email              VARCHAR(100)    NOT NULL,
  emailConta         VARCHAR(100)    NOT NULL,

  CONSTRAINT email_pk PRIMARY KEY(email),
  CONSTRAINT email_pessoa_fk FOREIGN KEY(emailConta) REFERENCES PESSOA(emailConta)
      ON UPDATE RESTRICT
      ON DELETE RESTRICT
)ENGINE=InnoDB;

CREATE TABLE tem(
  emailConta        VARCHAR(100)      NOT NULL,
  idCaracteristica  INT               NOT NULL,

  CONSTRAINT tem_pessoa_fk FOREIGN KEY(emailConta) REFERENCES PESSOA(emailConta)
      ON UPDATE RESTRICT
      ON DELETE RESTRICT,
  CONSTRAINT temp_caracteristica_fk FOREIGN KEY(idCaracteristica) REFERENCES CARACTERISTICA(idCaracteristica)
      ON UPDATE RESTRICT
      ON DELETE RESTRICT
)ENGINE=InnoDB;

CREATE TABLE relaciona(
  emailcontaInteressado      VARCHAR(100)      NOT NULL,
  emailContaDestinado        VARCHAR(100)      NOT NULL,

  CONSTRAINT relaciona_pessoainteressada_fk FOREIGN KEY(emailContaInteressado) REFERENCES PESSOSA(emailConta)
    ON UPDATE RESTRICT
    ON DELETE RESTRICT,

  CONSTRAINT relaciona_pessoadestinado_fk FOREIGN KEY(emailContaDestinado) REFERENCES PESSOA(emailConta)
 ENGINE=InnoDB;