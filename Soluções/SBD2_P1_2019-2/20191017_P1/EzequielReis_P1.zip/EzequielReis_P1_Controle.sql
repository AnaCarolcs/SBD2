﻿-- --------     << EzequielReis >>     ------------
-- 
--                    SCRIPT DE CONTROLE (DCL)
-- 
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Ezequiel De Oliveira Dos Reis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: EzequielReis
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de usuário
-- 
-- PROJETO => 01 Base de Dados
--         => 03 Tabelas
--         => 02 Usuarios
--
-- -----------------------------------------------------------------

CREATE USER 'ADMIN'@'localhost' IDENTIFIED BY 'admin';
GRANT ALL PRIVILEGES ON EzequielReis.* TO 'ADMIN';

CREATE USER 'PESSOA'@'localhost' IDENTIFIED BY 'pessoa';
GRANT SELECT, INSERT, DELETE, UPDATE ON EzequielReis.* TO 'PESSOA';