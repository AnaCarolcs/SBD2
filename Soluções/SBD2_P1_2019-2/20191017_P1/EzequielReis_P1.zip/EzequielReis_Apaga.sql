﻿  -- --------     << EzequielReis >>     ------------
--
--                    SCRIPT DE APAGAR (DDL)
--
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Ezequiel De Oliveira Dos Reis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: EzequielReis
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de usuário
--
-- PROJETO => 01 Base de Dados
--         => 03 Tabelas
--         => 02 Usuarios
--
-- ----------------------------------------------------------------

USE EzequielReis;

DROP TABLE formado;
DROP TABLE  leciona;
DROP TABLE  apto;
DROP TABLE   requisito;
DROP TABLE   composto;
DROP TABLE  DISCIPLINA;
DROP TABLE  email;
DROP TABLE   PROFESSOR;
DROP TABLE CURSO;



