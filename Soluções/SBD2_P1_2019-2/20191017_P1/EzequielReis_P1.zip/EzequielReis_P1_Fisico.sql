﻿  -- --------     << EzequielReis >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Ezequiel De Oliveira Dos Reis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: EzequielReis
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao de usuário
--
-- PROJETO => 01 Base de Dados
--         => 03 Tabelas
--         => 02 Usuarios
--
-- ----------------------------------------------------------------

CREATE DATABASE EzequielReis;

USE EzequielReis;

CREATE TABLE CURSO (
  idCurso BIGINT(10) NOT NULL,
  nomeCurso VARCHAR(50) NOT NULL,
  classificacao VARCHAR(50) NOT NULL,

  CONSTRAINT CURSO_PK PRIMARY KEY (idCurso)
)ENGINE = InnoDB;

CREATE TABLE PROFESSOR (
         matriculaFuncional BIGINT NOT NULL,
         primeiroNome VARCHAR(50) NOT NULL,
         ultimoNome VARCHAR(50) NOT NULL,
         dtNascimento DATETIME NOT NULL,
         sexo ENUM('M','F') NOT NULL,

          CONSTRAINT PROFESSOR_PK PRIMARY KEY (matriculaFuncional)
)ENGINE = InnoDB;

CREATE TABLE email (
  matriculaFuncional BIGINT NOT NULL,
  email VARCHAR(50) NOT NULL,

  CONSTRAINT professor_FK FOREIGN KEY (matriculaFuncional)  REFERENCES PROFESSOR(matriculaFuncional)
)ENGINE = InnoDB;


CREATE TABLE DISCIPLINA (
  idDisciplina BIGINT NOT NULL,
  nomeDisciplina VARCHAR(50) NOT NULL,
  sigla VARCHAR(50) NOT NULL,
  qtdCredito BIGINT(10) NOT NULL,
  perido VARCHAR(50) NOT NULL,

  CONSTRAINT DISCIPLINA_PK PRIMARY KEY (idDisciplina)

)ENGINE = InnoDB;

CREATE TABLE composto (
  idDisciplina BIGINT NOT NULL,
  idCurso BIGINT(10) NOT NULL,

  CONSTRAINT composto_disciplina_FK FOREIGN KEY (idDisciplina) REFERENCES DISCIPLINA(idDisciplina),
  CONSTRAINT composto_curso_FK FOREIGN KEY (idCurso) REFERENCES CURSO(idCurso)

)ENGINE = InnoDB;

CREATE TABLE requisito (
  idDisciplina BIGINT NOT NULL,
  idDisciplinaRequisito BIGINT NOT NULL,

  CONSTRAINT requisito_disciplina_FK FOREIGN KEY (idDisciplina) REFERENCES DISCIPLINA(idDisciplina),
  CONSTRAINT prerequisto_disciplina_FK FOREIGN KEY (idDisciplinaRequisito) REFERENCES DISCIPLINA(idDisciplina)

)ENGINE = InnoDB;

CREATE TABLE apto (
  matriculaFuncional BIGINT NOT NULL,
  idDisciplina BIGINT NOT NULL,

  CONSTRAINT apto_disciplina_FK FOREIGN KEY (idDisciplina) REFERENCES DISCIPLINA(idDisciplina),
  CONSTRAINT professor_apto_FK FOREIGN KEY (matriculaFuncional)  REFERENCES PROFESSOR(matriculaFuncional)

)ENGINE = InnoDB;


CREATE TABLE leciona (
  matriculaFuncional BIGINT NOT NULL,
  idDisciplina BIGINT NOT NULL,

  CONSTRAINT leciona_disciplina_FK FOREIGN KEY (idDisciplina) REFERENCES DISCIPLINA(idDisciplina),
  CONSTRAINT professor_leciona_FK FOREIGN KEY (matriculaFuncional)  REFERENCES PROFESSOR(matriculaFuncional)

)ENGINE = InnoDB;

CREATE TABLE formado (
  matriculaFuncional BIGINT NOT NULL,
  idCurso BIGINT NOT NULL,

  CONSTRAINT curso_formado_FK FOREIGN KEY (idCurso) REFERENCES CURSO(idCurso),
  CONSTRAINT professor_formado_FK FOREIGN KEY (matriculaFuncional)  REFERENCES PROFESSOR(matriculaFuncional)

)ENGINE = InnoDB;