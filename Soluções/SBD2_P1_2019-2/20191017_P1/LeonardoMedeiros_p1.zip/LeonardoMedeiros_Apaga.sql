﻿-- --------     << INSTITUICAO DE ENSINO >>     ------------
--
--                    SCRIPT DE APAGAR (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Leonardo de Araujo Medeiros
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: LeonardoMedeiros
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao da base de dados
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--
-- -----------------------------------------------------------------

USE LeonardoMedeiros;

DROP TABLE email;
DROP TABLE PROFESSOR;