﻿-- --------     << INSTITUICAO DE ENSINO >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Leonardo de Araujo Medeiros
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: LeonardoMedeiros
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao da base de dados
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS LeonardoMedeiros;

USE LeonardoMedeiros;

CREATE TABLE PROFESSOR (
  matriculaFuncional INT NOT NULL,
  primeiroNome VARCHAR(50) NOT NULL,
  ultimoNome VARCHAR(50) NOT NULL,
  dtNascimento DATE NOT NULL,
  CONSTRAINT PROFESSOR_PK PRIMARY KEY (matriculaFuncional)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8;

CREATE TABLE email (
  matriculaFuncional INT NOT NULL,
  email VARCHAR(50),
  CONSTRAINT email_PK PRIMARY KEY (matriculaFuncional, email),
  CONSTRAINT email_PROFESSOR_FK FOREIGN KEY (matriculaFuncional)
    REFERENCES PROFESSOR(matriculaFuncional)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=UTF8;

CREATE TABLE CURSO (
  idCurso INT NOT NULL,
  nomeCurso VARCHAR(50) NOT NULL,
  CONSTRAINT CURSO_PK PRIMARY KEY (idCurso)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8;

CREATE TABLE DISCIPLINA (
  idDisciplina INT NOT NULL,
  nomeDisciplina VARCHAR(50) NOT NULL,
  sigla VARCHAR(3) NOT NULL,
  qtdCreditos INT NOT NULL,
  idCurso INT NOT NULL,
  CONSTRAINT DISCIPLINA_PK PRIMARY KEY (idDisciplina),
  CONSTRAINT DISCIPLINA_CURSO_FK FOREIGN KEY (idCurso)
    REFERENCES CURSO(idCurso)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=UTF8;

CREATE TABLE leciona (
  matriculaFuncional INT NOT NULL,
  idDisciplina INT NOT NULL,
  CONSTRAINT leciona_DISCIPLINA_FK FOREIGN KEY (idDisciplina)
    REFERENCES DISCIPLINA(idDisciplina)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT,
  CONSTRAINT leciona_PROFESSOR_FK FOREIGN KEY (matriculaFuncional)
    REFERENCES PROFESSOR(matriculaFuncional)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=UTF8;

CREATE TABLE requisita (
  idDisciplina INT NOT NULL,
  idDisciplina_ INT NOT NULL,
  CONSTRAINT requisita_DISCIPLINA_FK FOREIGN KEY (idDisciplina)
    REFERENCES DISCIPLINA(idDisciplina)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT,
  CONSTRAINT requisita_DISCIPLINA_FK_ FOREIGN KEY (idDisciplina_)
    REFERENCES DISCIPLINA(idDisciplina)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=UTF8;