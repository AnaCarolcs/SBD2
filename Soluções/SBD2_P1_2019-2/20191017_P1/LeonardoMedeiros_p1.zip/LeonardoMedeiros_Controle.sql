﻿-- --------     << INSTITUICAO DE ENSINO >>     ------------
--
--                    SCRIPT DE CONTROLE (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Leonardo de Araujo Medeiros
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: LeonardoMedeiros
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao dos novos usuários ADMIN e PESSOA
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--
-- -----------------------------------------------------------------

-- ADMIN: Administrador da base de dados, possui todos os privilegios, tanto DDL quanto DML
CREATE USER ADMIN IDENTIFIED BY 'ADM1N#';
GRANT ALL PRIVILEGES ON LeonardoMedeiros.* to ADMIN;

-- PESSOA: Usuário comum da base de dados, tem acesso apenas às consultas DML
CREATE USER PESSOA IDENTIFIED BY 'P3550A$';
GRANT SELECT, INSERT ON LeonardoMedeiros.* to PESSOA;