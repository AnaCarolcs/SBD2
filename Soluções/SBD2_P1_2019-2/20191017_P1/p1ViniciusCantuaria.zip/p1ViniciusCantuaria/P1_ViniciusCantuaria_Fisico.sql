-- --------     << PROVA 1 >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Vinicius de Castro Cantuaria
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: ViniciusCantuaria
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao do Script
-- 
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--         => 03 Usuarios
--         => 02 Visoes
-- 
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS ViniciusCantuaria;

USE ViniciusCantuaria;

CREATE TABLE PESSOA (
    primeiroNome VARCHAR(30),
    sobrenome VARCHAR(60),
    sexo ENUM('M', 'F'),
    dtNascimento DATE,
    apelido VARCHAR(20),
    idPessoa INTEGER AUTO_INCREMENT,
    idOutraPessoa INTEGER,

    CONSTRAINT PESSOA_PK
    PRIMARY KEY (idPessoa),

    CONSTRAINT PESSOA_PESSOA_FK
    FOREIGN KEY (idOutraPessoa)
    REFERENCES PESSOA (idPessoa)
) ENGINE=InnoDB;

CREATE TABLE CARACTERISTICA (
    idCaracteristica INTEGER AUTO_INCREMENT,
    descCaracteristica VARCHAR(100),

    CONSTRAINT CARACTERISTICA_PK 
    PRIMARY KEY (idCaracteristica)
) ENGINE=InnoDB;

CREATE TABLE INTERESSE (
    idInteresse INTEGER AUTO_INCREMENT,
    descInteresse VARCHAR(100),

    CONSTRAINT INTERESSE_PK
    PRIMARY KEY (idInteresse)
) ENGINE=InnoDB;

CREATE TABLE email (
    email VARCHAR(50),
    idPessoa INTEGER,

    CONSTRAINT email_FK
    FOREIGN KEY (idPessoa)
    REFERENCES PESSOA (idPessoa)
) ENGINE=InnoDB;

CREATE TABLE relaciona (
    idPessoaOrigem INTEGER,
    idPessoaDestino INTEGER,

    CONSTRAINT relaciona_PESSOAORIGEM_FK
    FOREIGN KEY (idPessoaOrigem)
    REFERENCES PESSOA (idPessoa),

    CONSTRAINT relaciona_PESSOADESTINO_FK
    FOREIGN KEY (idPessoaDestino)
    REFERENCES PESSOA (idPessoa)
) ENGINE=InnoDB;

CREATE TABLE possui (
    idCaracteristica INTEGER,
    idPessoa INTEGER,

    FOREIGN KEY (idCaracteristica)
    REFERENCES CARACTERISTICA (idCaracteristica)
) ENGINE=InnoDB;

CREATE TABLE tem (
    idInteresse INTEGER,
    idPessoa INTEGER
) ENGINE=InnoDB;
 
ALTER TABLE possui ADD CONSTRAINT possui
    FOREIGN KEY (idPessoa)
    REFERENCES PESSOA (idPessoa)
    ON DELETE SET NULL;
 
ALTER TABLE tem ADD CONSTRAINT tem
    FOREIGN KEY (idInteresse)
    REFERENCES INTERESSE (idInteresse)
    ON DELETE SET NULL;
 
ALTER TABLE tem ADD CONSTRAINT tem
    FOREIGN KEY (idPessoa)
    REFERENCES PESSOA (idPessoa)
    ON DELETE SET NULL;