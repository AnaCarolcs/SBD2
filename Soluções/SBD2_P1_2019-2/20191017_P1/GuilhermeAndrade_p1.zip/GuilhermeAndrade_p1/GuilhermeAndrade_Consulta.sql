﻿-- --------     << P1 >>     ------------
-- 
--                    SCRIPT DE CONSULTA (DML)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Guilherme Guy de Andrade
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: GuilhermeAndrade
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao do projeto
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------

USE GuilhermeAndrade;

CREATE IF NOT EXISTS VIEW v_teste AS SELECT * FROM DISCIPLINA;