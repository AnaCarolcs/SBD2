﻿-- --------     << P1 >>     ------------
--
--                    SCRIPT DE CONTROLE (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Guilherme Guy de Andrade
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: GuilhermeAndrade
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao do projeto
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------

CREATE USER admin IDENTIFIED BY '!admin10';
GRANT ALL PRIVILEGES TO admin ON GuilhermeAndrade.*;

CREATE USER pessoa IDENTIFIED BY '!pessoa10';
GRANT SELECT TO pessoa ON GuilhermeAndrade.*;