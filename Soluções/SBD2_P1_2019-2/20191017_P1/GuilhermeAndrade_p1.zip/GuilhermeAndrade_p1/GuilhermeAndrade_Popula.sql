﻿-- --------     << P1 >>     ------------
-- 
--                    SCRIPT POPULA (DML)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Guilherme Guy de Andrade
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: GuilhermeAndrade
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao do projeto
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------

USE GuilhermeAndrade;

INSERT INTO PROFESSOR VALUE (1, 'Joao Robson', '1997-12-03', 'M');
INSERT INTO PROFESSOR VALUE (2, 'Carlos Cesar', '1995-12-03', 'M');
INSERT INTO PROFESSOR VALUE (3, 'Renato Silva', '1996-12-03', 'M');

INSERT INTO email VALUE (1, 'jrob@mail.com');
INSERT INTO email VALUE (2, 'carlos@mail.com');
INSERT INTO email VALUE (3, 'renat@mail.com');

INSERT INTO DISCIPLINA VALUE (1, 'Calculo 1', 'C1', 6, 'matutino');
INSERT INTO DISCIPLINA VALUE (2, 'Calculo 2', 'C2', 6, 'matutino');
INSERT INTO DISCIPLINA VALUE (3, 'Calculo 3', 'C3', 6, 'matutino');
INSERT INTO DISCIPLINA VALUE (4, 'Calculo Diferencial', 'EDO', 6, 'matutino');

INSERT INTO precisa VALUE(4, 3);
INSERT INTO precisa VALUE(3, 2);
INSERT INTO precisa VALUE(2, 1);

INSERT INTO leciona VALUE(1, 2);
INSERT INTO leciona VALUE(2, 3);
INSERT INTO leciona VALUE(2, 1);
INSERT INTO leciona VALUE(3, 2);
INSERT INTO leciona VALUE(4, 3);
INSERT INTO leciona VALUE(4, 1);


