﻿-- --------     << P1 >>     ------------
-- 
--                    SCRIPT DE DELECAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Guilherme Guy de Andrade
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: GuilhermeAndrade
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao do projeto
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------

USE GuilhermeAndrade;

DROP TABLE precisa;
DROP TABLE leciona;
DROP TABLE email;

DROP TABLE PROFESSOR;
DROP TABLE DISCIPLINA;