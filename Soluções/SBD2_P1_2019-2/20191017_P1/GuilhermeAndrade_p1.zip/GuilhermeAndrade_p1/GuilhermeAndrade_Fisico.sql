﻿-- --------     << P1 >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Guilherme Guy de Andrade
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: GuilhermeAndrade
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao do projeto
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--         => 02 Usuarios
--         => 01 Visao
--
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS GuilhermeAndrade;

USE GuilhermeAndrade;

CREATE TABLE PROFESSOR (
    matricula INT(4) NOT NULL,
    nome VARCHAR(250)NOT NULL,
    dataNascimento DATE NOT NULL,
    sexo ENUM('M','F') NOT NULL,

  CONSTRAINT PROFESSOR_PK PRIMARY KEY (matricula)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE DISCIPLINA (
    idDisciplina INT(4) NOT NULL,
    nome VARCHAR(250) NOT NULL,
    sigla VARCHAR(10) NOT NULL,
    creditos INT(4) NOT NULL,
    periodo ENUM('matutino', 'vespertino', 'noturno') NOT NULL,

    CONSTRAINT DISCIPLINA_PK PRIMARY KEY (idDisciplina)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE email (
    matricula INT(4) NOT NULL,
    email VARCHAR(250) NOT NULL,

  CONSTRAINT email_PK PRIMARY KEY (email),
  CONSTRAINT email_PROFESSOR_FK FOREIGN KEY (matricula) REFERENCES PROFESSOR(matricula)
) ENGINE = InnoDB;

CREATE TABLE precisa (
    idDependente INT(4) NOT NULL,
    idDisciplina INT(4) NOT NULL,
    UNIQUE (idDependente, idDisciplina),

    CONSTRAINT DISCIPLINA_dependente_precisa_FK FOREIGN KEY (idDependente) REFERENCES DISCIPLINA(idDisciplina),
    CONSTRAINT DISCIPLINA_precisa_FK FOREIGN KEY (idDisciplina) REFERENCES DISCIPLINA (idDisciplina)
) ENGINE = InnoDB;


CREATE TABLE leciona (

    idDisciplina INT(4) NOT NULL,
    matricula INT(4) NOT NULL,
    UNIQUE (idDisciplina, matricula),

    CONSTRAINT leciona_DISCIPLINA_FK FOREIGN KEY (idDisciplina) REFERENCES DISCIPLINA(idDisciplina),
    CONSTRAINT leciona_PROFESSOR_FK FOREIGN KEY (matricula) REFERENCES PROFESSOR(matricula)

) ENGINE = InnoDB;