-- --------            << TF_I_dupla1_fim >>     ------------------
-- 
--                    SCRIPT DE APAGA (DDL)
-- 
-- Data Criacao ...........: 02/12/2019
-- Autor(es) ..............: Gabriel Alves
-- Banco de Dados .........: Oracle
-- Esquema(nome) ..........: FGA_SBD
-- 
-- 
-- PROJETO => 03 Tabelas
--         => 02 Sequencias
--         => 03 Triggers
--         => 03 Views
--         => 01 Índice
-- 
-- -----------------------------------------------------------------

DROP TABLE GASS_FUNCIONARIO;
DROP TABLE GASS_DEPARTAMENTO;
DROP TABLE GASS_GERENTE;