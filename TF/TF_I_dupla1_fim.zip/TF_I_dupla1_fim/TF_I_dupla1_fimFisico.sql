-- --------     << TF_I_dupla1_fim >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 30/11/2019
-- Autor(es) ..............: Gabriel Alves
-- Banco de Dados .........: Oracle
-- Esquema(nome) ..........: FGA_SBD
-- 
-- 
-- PROJETO => 03 Tabelas
--         => 02 Sequencias
--         => 03 Triggers
--         => 03 Views
--         => 01 Índice
-- 
-- -----------------------------------------------------------------

CREATE TABLE "GASS_GERENTE"
(
    "MATRICULA" NUMBER NOT NULL
    ENABLE, 
	"NOME" VARCHAR2
    (50) NOT NULL ENABLE, 
	"SALARIO" NUMBER
    (7,2) NOT NULL ENABLE, 
	"EMAIL" VARCHAR2
    (50), 
	 CONSTRAINT "GASS_GERENTE_PK" PRIMARY KEY
    ("MATRICULA") USING INDEX  ENABLE, 
	 CONSTRAINT "GASS_GERENTE_UK" UNIQUE
    ("EMAIL") USING INDEX  ENABLE
);

    CREATE sequence "GASS_FUNCIONARIO_SEQ";

    CREATE trigger "BI_GASS_GERENTE"  
before
    insert on
    "GASS_GERENTE"
    for
    each
    row
    begin
        if :NEW."MATRICULA" is null then
        select "GASS_FUNCIONARIO_SEQ".nextval
        into
    :NEW."MATRICULA" from sys.dual;
    end
    if; 
end;

    CREATE TABLE "GASS_DEPARTAMENTO"
    (
        "ID" NUMBER NOT NULL
        ENABLE, 
	"GERENTE"   NUMBER NOT NULL ENABLE, 
	"DESCRICAO" VARCHAR2
        (30) NOT NULL ENABLE, 
	CONSTRAINT "GASS_DEPARTAMENTO_PK" PRIMARY KEY
        ("ID") USING INDEX  ENABLE,
    CONSTRAINT "GASS_DEPARTAMENTO_FK_GERENTE" FOREIGN KEY
        ("GERENTE") REFERENCES "GASS_GERENTE"
        ("MATRICULA") ENABLE
);

        CREATE sequence "GASS_DEPARTAMENTO_SEQ";


        CREATE OR REPLACE TRIGGER  "BI_GASS_DEPARTAMENTO" 
before
        insert on
        "GASS_DEPARTAMENTO"
        for
        each
        row
        begin
            if :NEW."ID" is null then
            select "GASS_DEPARTAMENTO_SEQ".nextval
            into
        :NEW."ID" from sys.dual;
        end
        if; 
end;

        CREATE TABLE "GASS_FUNCIONARIO"
        (
            "MATRICULA" NUMBER NOT NULL
            ENABLE, 
	"DEPARTAMENTO" NUMBER NOT NULL ENABLE, 
	"NOME" VARCHAR2
            (50) NOT NULL ENABLE, 
	"SALARIO" NUMBER
            (7,2) NOT NULL ENABLE, 
	"EMAIL" VARCHAR2
            (50), 
	 CONSTRAINT "GASS_FUNCIONARIO_PK" PRIMARY KEY
            ("MATRICULA") USING INDEX  ENABLE, 
	 CONSTRAINT "GASS_FUNCIONARIO_UK" UNIQUE
            ("EMAIL") USING INDEX  ENABLE,
     CONSTRAINT "GASS_FUNCIONARIO_FK_DEPARTAMENTO" FOREIGN KEY
            ("DEPARTAMENTO") REFERENCES "GASS_DEPARTAMENTO"
            ("ID") ENABLE
);

            CREATE trigger "BI_GASS_FUNCIONARIO"  
before
            insert on
            "GASS_FUNCIONARIO"
            for
            each
            row
            begin
                if :NEW."MATRICULA" is null then
                select "GASS_FUNCIONARIO_SEQ".nextval
                into
            :NEW."MATRICULA" from sys.dual;
            end
            if; 
end;