-- --------            << TF_I_dupla1_fim >>     ------------------
-- 
--                    SCRIPT DE CONSULTA (DQL)
-- 
-- Data Criacao ...........: 30/11/2019
-- Autor(es) ..............: Gabriel Alves
-- Banco de Dados .........: Oracle
-- Esquema(nome) ..........: FGA_SBD
-- 
-- 
-- PROJETO => 03 Tabelas
--         => 02 Sequencias
--         => 03 Triggers
--         => 03 Views
--         => 01 Índice
-- 
-- -----------------------------------------------------------------

/* Essa view disponibiliza ao usuário interessado, os departamentos da empresa
   junto com o seu respectivo gasto salarial, facilitando a visualização dos 
   departamento que possuem maior e menor custo dentro da organização.
*/
create or replace view "VW_GASS_SALARIO_DEPARTAMENTO" as
select d.descricao DEPARTAMENTO, sum(f.salario) FAIXA_SALARIAL
from GASS_FUNCIONARIO f
    inner join GASS_DEPARTAMENTO d
    on f.departamento = d.id
group by d.descricao

/* Essa view disponibiliza ao usuário interessado, a quantidade de funcionários
   de cada departamento, podendo assim facilitar a tomada de decisão de qual de-
   partamento tem preferencia na contratação de novos funcionários.
*/
create or replace view "VW_GASS_NUM_FUNCIONARIOS" as
select d.descricao DEPARTAMENTO, count(f.matricula) N_FUNCIONARIOS
from GASS_FUNCIONARIO f
    inner join GASS_DEPARTAMENTO d
    on f.departamento = d.id
group by d.descricao

/* Essa consulta, otimizada com o seu respectivo índice abaixo, disponibiliza
   ao usuário interessado, o nome do funcionário e seu respectivo gerente, fa-
   cilitando possíveis reclamações, elogios ou solicitação de informações adi-
   cionais diretamente com o respectivo gerente do funcionário interessado.
*/
create index gass_nome_funcionario_idx
on GASS_FUNCIONARIO(nome);

select f.nome FUNCIONARIO, g.nome GERENTE
from GASS_FUNCIONARIO f
    INNER JOIN GASS_DEPARTAMENTO d
    on f.departamento = d.id
    INNER JOIN GASS_GERENTE g
    on g.matricula = d.gerente