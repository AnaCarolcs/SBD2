-- --------            << TF_I_dupla1_fim >>     ------------------
-- 
--                    SCRIPT DE POPULA (DML)
-- 
-- Data Criacao ...........: 30/11/2019
-- Autor(es) ..............: Gabriel Alves
-- Banco de Dados .........: Oracle
-- Esquema(nome) ..........: FGA_SBD
-- 
-- 
-- PROJETO => 03 Tabelas
--         => 02 Sequencias
--         => 03 Triggers
--         => 03 Views
--         => 01 Índice
-- 
-- -----------------------------------------------------------------

-- 7 Inserções na tabela de Gerentes
INSERT INTO GASS_GERENTE
    (nome, salario, email)
VALUES
    ('Gabriel Alves', 5000, 'gabrielemrede@gmail.com');
INSERT INTO GASS_GERENTE
    (nome, salario, email)
VALUES
    ('Lucas Fernandes', 7500, 'fernandesl@hotmail.com');
INSERT INTO GASS_GERENTE
    (nome, salario, email)
VALUES
    ('Letícia Magalhães', 12500, 'letimaga@gmail.com');
INSERT INTO GASS_GERENTE
    (nome, salario, email)
VALUES
    ('Ana Raquel', 7800, 'raquelana@gmail.com');
INSERT INTO GASS_GERENTE
    (nome, salario, email)
VALUES
    ('Amom Rodrigues', 9800, 'amomrodrigues@gmail.com');
INSERT INTO GASS_GERENTE
    (nome, salario, email)
VALUES
    ('Paula Nascimento', 5200, 'paulanasc@hotmail.com');
INSERT INTO GASS_GERENTE
    (nome, salario, email)
VALUES
    ('Mariana Rocha', 6750, 'marirocha@google.com');

-- 7 Inserções na tabela de Departamentos
INSERT INTO GASS_DEPARTAMENTO
    (descricao, gerente)
VALUES
    ('Criação', 42);
INSERT INTO GASS_DEPARTAMENTO
    (descricao, gerente)
VALUES
    ('Diretoria', 43);
INSERT INTO GASS_DEPARTAMENTO
    (descricao, gerente)
VALUES
    ('Desenvolvimento', 73);
INSERT INTO GASS_DEPARTAMENTO
    (descricao, gerente)
VALUES
    ('Recursos Humanos', 71);
INSERT INTO GASS_DEPARTAMENTO
    (descricao, gerente)
VALUES
    ('Financeiro', 72);
INSERT INTO GASS_DEPARTAMENTO
    (descricao, gerente)
VALUES
    ('Marketing', 21);
INSERT INTO GASS_DEPARTAMENTO
    (descricao, gerente)
VALUES
    ('Vendas', 1);


-- 10 mil inserções na tabela de Funcionários do tipo Venda
BEGIN
    FOR i IN 1..10000
LOOP
    INSERT INTO GASS_FUNCIONARIO
        (nome, salario, departamento, email)
    VALUES
        ('Funcionário ' || i, 1500, 1, 'funcionario' || i || '@tf_i_dupla1.com');
END
LOOP;
END;

-- 100 inserções na tabela de Funcionários do tipo Diretoria
BEGIN
    FOR i IN 10001..10101
LOOP
    INSERT INTO GASS_FUNCIONARIO
        (nome, salario, departamento, email)
    VALUES
        ('Funcionário ' || i, 3000, 21, 'funcionario' || i || '@tf_i_dupla1.com');
END
LOOP;
END;

-- 300 inserções na tabela de Funcionários do tipo Criação
BEGIN
    FOR i IN 10102..10402
LOOP
    INSERT INTO GASS_FUNCIONARIO
        (nome, salario, departamento, email)
    VALUES
        ('Funcionário ' || i, 2200, 41, 'funcionario' || i || '@tf_i_dupla1.com');
END
LOOP;
END;

-- 100 inserções na tabela de Funcionários do tipo Desenvolvimento
BEGIN
    FOR i IN 10403..10553
LOOP
    INSERT INTO GASS_FUNCIONARIO
        (nome, salario, departamento, email)
    VALUES
        ('Funcionário ' || i, 4200, 22, 'funcionario' || i || '@tf_i_dupla1.com');
END
LOOP;
END;

-- 200 inserções na tabela de Funcionários do tipo Recursos Humanos
BEGIN
    FOR i IN 10554..10754
LOOP
    INSERT INTO GASS_FUNCIONARIO
        (nome, salario, departamento, email)
    VALUES
        ('Funcionário ' || i, 1700, 23, 'funcionario' || i || '@tf_i_dupla1.com');
END
LOOP;
END;

-- 100 inserções na tabela de Funcionários do tipo Financeiro
BEGIN
    FOR i IN 10755..10855
LOOP
    INSERT INTO GASS_FUNCIONARIO
        (nome, salario, departamento, email)
    VALUES
        ('Funcionário ' || i, 3900, 24, 'funcionario' || i || '@tf_i_dupla1.com');
END
LOOP;
END;

-- 100 inserções na tabela de Funcionários do tipo Marketing
BEGIN
    FOR i IN 10856..10956
LOOP
    INSERT INTO GASS_FUNCIONARIO
        (nome, salario, departamento, email)
    VALUES
        ('Funcionário ' || i, 3900, 42, 'funcionario' || i || '@tf_i_dupla1.com');
END
LOOP;
END;