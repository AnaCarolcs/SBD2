﻿-- -----------         << Aula 1 Exercício 2 >>      ------------------
--                                                                   --
--                    SCRIPT DE REMOÇÃO                              --
--                                                                   --
-- Data Criacao ..........: 19/08/2018                               --
-- Autor(es) .............: Ana Carolina Carvalho da Silva           --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: aula1exer2                               --
--                                                                   --
-- Data Ultima Alteracao ..: 19/08/2019                              --
--    + Remoção do banco de dados                                    --
--                                                                   --
-- PROJETO => 01 Base de Dados                                       --
--         => 06 Tabelas                                             --
--                                                                   --
-- ----------------------------------------------------------------- --

use aula1exer2;

DROP TABLE vende;
DROP TABLE supervisiona;
DROP TABLE telefone;
DROP TABLE PRODUTO;
DROP TABLE EMPREGADO;
DROP TABLE GERENTE;