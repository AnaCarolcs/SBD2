﻿-- --------       << Aula 1 Exercicio 2 Evolucao 3 >>      --------- --
--                                                                   --
--                    SCRIPT DE CONSULTA(DML)                        --
--                                                                   --
-- Data Criacao ..........: 25/08/2019                               --
-- Autor(es) .............: Ana Carolina Carvalho da Silva           --
--                                                                   --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: bdAula1Exer2Evol3                        --
--                                                                   --
-- Data Ultima Alteracao ..: 25/08/2019                              --
--                          + Gerar consultas                        --
--                                                                   --
-- PROJETO => 01 Base de Dados                                       --
--         => 12 Tabelas                                             --
--                                                                   --
-- ----------------------------------------------------------------- --

USE bdAula1Exer2Evol3;

-- A) Consultar todas as vendas feitas por um empregado
--    específico definido pela sua chave primária;

select matriculaEmpregado, precoTotal, dataVenda, idVenda FROM
       VENDA WHERE matriculaEmpregado = '265321';

-- B) Relacionar todos os dados de uma venda com todas as
--    informações dos produtos comercializados por esta venda específica;

select v.dataVenda, p.idVenda, p.idProduto, p.quantidade, v.precoTotal FROM
       possui AS p JOIN VENDA AS v WHERE p.idVenda = v.idVenda;

-- C) Mostrar todos os empregados da empresa que não sejam
--    gerentes em ordem alfabética crescente;

select nome, EMPREGADO.CPF, EMPREGADO.matricula FROM EMPREGADO INNER JOIN PESSOA
        ON EMPREGADO.CPF = PESSOA.CPF LEFT OUTER JOIN GERENTE on PESSOA.CPF = GERENTE.CPF
        WHERE GERENTE.CPF IS NULL order by nome;

-- D) Consultar e mostrar a quantidade de cada produto que foi vendido por esta empresa;

select idProduto, quantidade from possui;