﻿-- --------       << Aula 1 Exercicio 2 Evolucao 3 >>      ------------
--                                                                   --
--                    SCRIPT DE APAGA (DDL)                          --
--                                                                   --
-- Data Criacao ...........: 19/08/2019                              --
-- Autor(es) ..............:Ana Carolina Carvalho                    --
--							                                                     --
-- Banco de Dados .........: MySQL                                   --
-- Base de Dados(nome) ....: aula1exer2                              --
--                                                                   --
-- Data Ultima Alteracao ..: 25/08/2019                              --
--                           => Evolução 03                           --
--                                                                   --
-- PROJETO => 01 Base de Dados                                       --
--         => 12 Tabelas                                             --
--                                                                   --
-- --------------------------------------------------------------------

USE aula1exer2;

DROP TABLE PRODUTO;
DROP TABLE AREA;
DROP TABLE telefone;
DROP TABLE EMPREGADO;
DROP TABLE GERENTE;
DROP TABLE PESSOA;
DROP TABLE administra;
DROP TABLE pertence;
DROP TABLE possui;
DROP TABLE realiza;
DROP TABLE gerencia;
DROP TABLE VENDA;
