﻿-- --------       << Aula 1 Exercicio 2 Evolucao 3 >>      --------- --
--                                                                   --
--                    SCRIPT DE POPULA (DML)                         --
--                                                                   --
-- Data Criacao ...........: 19/08/2019                              --
-- Autor(es) ..............:Ana Carolina Carvalho                    --
--                                                                   --
-- Banco de Dados .........: MySQL                                   --
-- Base de Dados(nome) ....: aula1exer2                              --
--                                                                   --
-- Data Ultima Alteracao ..: 25/08/2019                              --
--                           => Evolução 03                          --
--                                                                   --
-- PROJETO => 01 Base de Dados                                       --
--         => 12 Tabelas                                             --
--                                                                   --
-- --------------------------------------------------------------------

USE aula1exer2;

INSERT INTO PESSOA VALUES
  (09976933321, 'Pedro Barbosa', 'pd01ba23'),
  (09831231211, 'Joana Almeida', 'mstopra21'),
  (43137123211, 'João Pinto', 'rqsdd12'),
  (67390120932, 'Giovanna Queiroz', 'amora97'),
  (43127381232, 'Ivan Santos', 'klab32'),
  (71152813231, 'Joaquim Oliveira', 'oliver123');

INSERT INTO GERENTE VALUES
  ('pedro@gmail.com', 'superior', 09976933321),
  ('almeida@gmail.com', 'superior', 09831231211),
  ('joaoli@gmail.com', 'superior', 43137123211);

INSERT INTO EMPREGADO VALUES
  (265321, 67390120932, 43, 'Rua Algusto Ribeiro', 'Setor Norte', 'Gama', 'DF', 72300000, NULL),
  (296232, 43127381232, 24, 'QR 210 conj 04 ', 'Norte', 'Ceilândia', 'DF', 31241200, 'Ao lado do Banco'),
  (332172, 71152813231, 25, 'QNJ', 'Sul', 'Taguatinga', 'DF', 89132122, NULL);

INSERT INTO telefone VALUES
  (265321, 5561999961224),
  (296232, 5561997162322),
  (332172, 5561997368221);

INSERT INTO gerencia VALUES
  (09976933321, 265321),
  (09831231211, 296232),
  (43137123211, 332172);

INSERT INTO AREA VALUES
  (1, 'Esportes'),
  (2, 'Informática'),
  (3, 'Jogos');

INSERT INTO PRODUTO VALUES
  (3243, 1, 'luva de box 15 oz'),
  (2342, 2, 'mause xtz 3'),
  (2232, 3, 'fifa 19');
	
INSERT INTO possui VALUES
	(306, 3243, 6),
	(888, 2342, 2),
	(404, 2232, 1);

INSERT INTO VENDA VALUES
	(168745932, 306, "2018-06-12", 90.24),
	(180256478, 888, "2017-05-03", 9.99),
	(180256478, 1006, "2017-05-06", 69.56),
	(178899000, 404, "2019-01-02", 125.99);

INSERT INTO realiza (matricula, idVenda) VALUES
	(265321, 306),
	(296232, 888),
	(332172, 404);

INSERT INTO pertence (idProduto, codigoArea) VALUES
	(1156656, 1),
	(0211561, 2),
	(8484156, 3);

INSERT INTO administra (CPFgerente, codigoArea) VALUES
	(09976933321, 1),
	(09831231211, 2),
	(43137123211, 3);