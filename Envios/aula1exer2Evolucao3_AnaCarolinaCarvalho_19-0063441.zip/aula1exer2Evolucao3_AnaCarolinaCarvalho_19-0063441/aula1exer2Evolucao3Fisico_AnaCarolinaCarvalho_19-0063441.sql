﻿-- --------       << Aula 1 Exercicio 2 Evolucao 3 >>      --------- --
--                                                                   --
--                    SCRIPT DE CRIACAO (DDL)                        --
--                                                                   --
-- Data Criacao ...........: 19/08/2019                              --
-- Autor(es) ..............:Ana Carolina Carvalho                    --
--                                                                   --
-- Banco de Dados .........: MySQL                                   --
-- Base de Dados(nome) ....: aula1exer2                              --
--                                                                   --
-- Data Ultima Alteracao ..: 25/08/2019                              --
--                           => Evolução 03                          --
--                                                                   --
-- PROJETO => 01 Base de Dados                                       --
--         => 12 Tabelas                                             --
--                                                                   --
-- --------------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula1exer2;

USE aula1exer2;

CREATE TABLE PESSOA (
    cpf BIGINT(11) NOT NULL,
    nome VARCHAR(50) NOT NULL,
    senha VARCHAR(20) NOT NULL,
CONSTRAINT PESSOA_PK PRIMARY KEY (cpf)
) ENGINE=InnoDB;

CREATE TABLE GERENTE (
    email VARCHAR(50) NOT NULL,
	formacao VARCHAR(50) NOT NULL,
    cpf BIGINT(11) NOT NULL,
CONSTRAINT GERENTE_PK PRIMARY KEY (cpf),
CONSTRAINT GERENTE_PESSOA_fk FOREIGN KEY (cpf)
	REFERENCES PESSOA (cpf)
) ENGINE=InnoDB;

CREATE TABLE EMPREGADO (
    matricula INT (10) NOT NULL,
    cpf BIGINT(11) NOT NULL UNIQUE,
    numero INT (10) NOT NULL,
    logradouro VARCHAR(50) NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    uf VARCHAR(2) NOT NULL,
    cep INT(8) NOT NULL,
    complemento VARCHAR(50),
CONSTRAINT EMPREGADO_PK PRIMARY KEY (matricula),
CONSTRAINT EMPREGADO_PESSOA_FK FOREIGN KEY (cpf)
	REFERENCES PESSOA (cpf)
) ENGINE=InnoDB;

CREATE TABLE telefone (
    matricula INT NOT NULL,
    telefone BIGINT(14) NOT NULL,
CONSTRAINT telefone_EMPREGADO_FK FOREIGN KEY (matricula)
	REFERENCES EMPREGADO (matricula)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS gerencia (
    CPFgerente BIGINT NOT NULL,
    matricula BIGINT NOT NULL,
    CONSTRAINT FK_gerencia_GERENTE FOREIGN KEY (CPFGerente) REFERENCES GERENTE (CPF),
    CONSTRAINT FK_gerencia_EMPREGADO FOREIGN KEY (matricula) REFERENCES EMPREGADO (matricula)
) ENGINE=InnoDB;

CREATE TABLE AREA (
    idArea INT (10) NOT NULL AUTO_INCREMENT,
    nomeArea VARCHAR(50) NOT NULL,
CONSTRAINT AREA_PK PRIMARY KEY (idArea)
) ENGINE=InnoDB AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS PRODUTO (
    idProduto BIGINT (20) NOT NULL,
    nomeProduto VARCHAR(30) NOT NULL,
    precoUnitario FLOAT (4) NOT NULL,
    idArea INT NOT NULL,
    CONSTRAINT PK_PRODUTO PRIMARY KEY (idProduto),
    CONSTRAINT FK_PRODUTO_AREA FOREIGN KEY (idArea) REFERENCES AREA (idArea)
) ENGINE=InnoDB, AUTO_INCREMENT = 1;


CREATE TABLE IF NOT EXISTS VENDA (
    idVenda INT NOT NULL AUTO_INCREMENT,
    dataVenda DATE NOT NULL,
    preco_total FLOAT,
    matriculaEmpregado BIGINT NOT NULL,
    CONSTRAINT PK_VENDA PRIMARY KEY (idVenda),
    CONSTRAINT FK_VENDA_EMPREGADO FOREIGN KEY(matriculaEmpregado) REFERENCES EMPREGADO(matricula)
) ENGINE=InnoDB, AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS realiza (
    matricula BIGINT NOT NULL,
    idVenda INT NOT NULL,
    CONSTRAINT FK_realiza_EMPREGADO FOREIGN KEY (matricula) REFERENCES EMPREGADO (matricula),
    CONSTRAINT FK_realiza_VENDA FOREIGN KEY (idVenda) REFERENCES VENDA (idVenda)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS possui (
    idVenda INT NOT NULL,
    idProduto BIGINT NOT NULL,
    quantidade INT NOT NULL,
    CONSTRAINT FK_possui_VENDA FOREIGN KEY (idVenda) REFERENCES VENDA (idVenda),
    CONSTRAINT FK_possui_PRODUTO FOREIGN KEY (idProduto) REFERENCES PRODUTO (idProduto)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pertence (
    idProduto BIGINT NOT NULL,
    idArea INT NOT NULL,
    CONSTRAINT FK_pertence_PRODUTO FOREIGN KEY (idProduto) REFERENCES PRODUTO (idProduto),
    CONSTRAINT FK_pertence_AREA FOREIGN KEY (idArea) REFERENCES AREA (idArea)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS administra (
    CPFgerente BIGINT NOT NULL,
    idArea INT NOT NULL,
    CONSTRAINT FK_administra_GERENTE FOREIGN KEY (CPFGerente) REFERENCES GERENTE (CPF),
    CONSTRAINT FK_administra_AREA FOREIGN KEY (idArea) REFERENCES AREA (idArea)
) ENGINE=InnoDB;