﻿-- --------     << PESSOA >>     ------------
--
--                    SCRIPT DE POPULA
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Ana Carolina Carvalho
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: anasilva
--
-- Data Ultima Alteracao ..: 17/10/2019
--
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuarios
--
-- ----------------------------------------------------

-- Popula:

USE anasilva;

INSERT PESSOA (idPessoa, primeironome, ultimonome, apelido, idade, sexo, dtNascimento,email) VALUES
    ('1', 'Ana', 'Carvalho', 'Carol', '23', 'F', '23-08-1996'),
    ('2', 'Rafael', 'Silva', 'Rafa', '20', 'M', '17-01-1998'),
    ('3', 'Maria', 'Santos', 'Mari', '29', 'F', '23-08-1990'),
    ('4', 'Soares', 'Ze', '28', 'M', '24-08-1991');

INSERT email (idPessoa, email) VALUES
    ('1','ana@email.com'),
    ('2','rafa@email.com'),
    ('3','maria@email.com'),
    ('4','jose@email.com');

INSERT CARACTERISTICA (idCaracteristica, pessoal, interesse) VALUES
    ('10', 'amigos', 'corrida'),
    ('11', 'namoro', 'jogos'),
    ('13', 'amigos', 'hidroginastica'),
    ('12', 'amigas', 'croche');