﻿-- -------------------   << REVISAO P1 >>    -------------------- --
--                                                                --
--                     SCRIPT DE APAGA (DDL)                      --
--                                                                --
-- DATE Criacao ...........: 04/05/2019                           --
-- Autor(es) ..............: Paulo Victor de Menezes Lopes        --
-- Banco de Dados .........: MySQL                                --
-- Banco de Dados(nome) ...: bdEscola                             --
--                                                                --
-- PROJETO => 01 Base de Dados                                    --
--         => 05 Tabelas                                          --
--         => 01 Visao                                            --
--                                                                --
-- -----------------------------------------------------------------

USE bdEscola;

DROP TABLE atua;
DROP TABLE projeto;
DROP TABLE telefone;
DROP TABLE cliente;
DROP TABLE profissional;