﻿-- --------     << aula3exer1Evolucao4 >>     ------------
-- 
--                    SCRIPT DE MANIPULACAO (DML)
-- 
-- date Criacao ...........: 07/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
--                           Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySql
-- Base de Dados(nome) ....: aula3exer1Evolucao4
-- 
-- date Ultima Alteracao ..: 14/10/2019
--   => Inserção de dados na base
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--         => 02 Views 	 
--         => 03 Usuários
-- -----------------------------------------------------------------
USE aula3exer1Evolucao4;

INSERT INTO ESPECIALIDADE (idEspecialidade, tipoEspecialidade) VALUES
	(default, 'Enfermeiro Geral'),
	(default, 'Acupuntura'),
	(default, 'Alergia e Imunologia'),
	(default, 'Anestesiologia');

INSERT INTO ESPECIALIDADE (tipoEspecialidade) VALUES
	('Angiologia'),
	('Cancerologia'),
	('Urologia');


INSERT INTO SETOR (idSetor, nomeSetor) VALUES
	(default, 'Acupuntura'),
	(default, 'Anestesiologia'),
	(default, 'Urologia');


INSERT INTO PLANTONISTA (matricula, nome, sexo, idEspecialidade) VALUES
	(default, 'João Silva da Silva', 'M', 1),
	(default, 'Maria Souza da Silva', 'F', 3),
	(default, 'João Pedro Alves', 'M', 2);


INSERT INTO alocado (idSetor, matricula, datahora) VALUES
	(1, 2, '2019-10-09 2:00:00'),
	(1, 1, '2019-11-09 7:00:00'),
	(2, 3, '2019-09-22 5:00:00');
