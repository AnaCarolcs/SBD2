﻿-- --------     << aula3exer1Evolucao4 >>     ------------
-- 
--                    SCRIPT DE EXCLUSAO (DDL)
-- 
-- date Criacao ...........: 07/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
--                           Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySql
-- Base de Dados(nome) ....: aula3exer1Evolucao4
-- 
-- date Ultima Alteracao ..: 14/10/2019
--   => Apaga tabelas, usuários e views sem apagar a base
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--         => 02 Views 	 
--         => 03 Usuários
-- -----------------------------------------------------------------
USE aula3exer1Evolucao4;

 -- VISAO
DROP VIEW VIEW_PLANTOES;
DROP VIEW VIEW_ATENDIMENTO;

 -- TABELAS
DROP TABLE alocado;
DROP TABLE PLANTONISTA;
DROP TABLE ESPECIALIDADE;
DROP TABLE SETOR;

-- USUARIOS
DROP USER administrador;
DROP USER usuario;
DROP USER gestor;
