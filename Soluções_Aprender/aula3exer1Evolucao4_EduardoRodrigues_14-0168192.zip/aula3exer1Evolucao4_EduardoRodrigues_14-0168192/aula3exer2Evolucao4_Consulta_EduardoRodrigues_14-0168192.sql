﻿-- --------     << aula3exer1Evolucao4 >>     ------------
-- 
--                    SCRIPT DE CONSULTAS (DML)
--
-- date Criacao ...........: 07/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
--                           Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySql
-- Base de Dados(nome) ....: aula3exer1Evolucao4
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--         => 02 Views
--         => 03 Usuários
-- -----------------------------------------------------------------

USE aula3exer1Evolucao4;

/*
USUARIO: gestor
OBJETIVO: Permite visualizar os atendimentos que cada plantonista
  vai realizar em cada setor entre duas datas.
  Auxilia os responsáveis pela criação das escalas a melhor distribuir
  os plantonistas de forma a atender todos os setores.
CLÁUSULA: Data inicial e final que se deseja obter as informações
  dos plantonistas alocados.
*/
CREATE OR REPLACE VIEW VIEW_PLANTOES (setor, dtHora, plantonista, matricula) AS
	SELECT s.nomeSetor, a.dataHora, p.nome, p.matricula
		FROM alocado a
			INNER JOIN SETOR s
				ON a.idSetor=s.idSetor
			INNER JOIN PLANTONISTA p
				ON a.matricula=p.matricula
		WHERE a.dataHora BETWEEN '2019-09-22 5:00:00' AND '2019-10-09 2:00:00'
		ORDER BY p.matricula, s.nomeSetor;


/*
  Pela quantidade de dados cadastrados na base de dados, não seria
  necessário o uso de índice. Supondo que a base tivesse um grande
  volume de dados, poderia se utilizar índice nesta view para as datas,
  uma vez que se tem a intenção de recuperar rapidamente as tuplas que
  possuam datas entre dois intervalos.
*/
-- CRIANDO INDICE PARA VIEW_PLATOES
CREATE INDEX PLANTOES_IDX  ON alocado(dataHora);



/*
USUARIO: Usuário (PLANTONISTA)
OBJETIVO: Permite visualizar o setor e horário em que o plantonista
  irá atender em uma determinada data.
CLÁUSULA: Data do plantão e matrícula do plantonista
*/
CREATE OR REPLACE VIEW VIEW_ATENDIMENTO (Setor, Data, Matricula) as
	SELECT s.nomeSetor, a.dataHora, p.matricula
		FROM alocado a
			INNER JOIN SETOR s
				ON s.idSetor=a.idSetor
			INNER JOIN PLANTONISTA p
				ON p.matricula=a.matricula
		WHERE a.dataHora LIKE('2019-10-09 %')
      AND a.matricula='2';


/*
  Para tornar a consulta mais eficiente e como ela provavelmente
  seria executada várias vezes por diferentes usuários, seria
  interessante utilzar a data e matrícula como índices.
*/
CREATE INDEX ALOCADO_MATRICULA_IDX  ON alocado(matricula);
