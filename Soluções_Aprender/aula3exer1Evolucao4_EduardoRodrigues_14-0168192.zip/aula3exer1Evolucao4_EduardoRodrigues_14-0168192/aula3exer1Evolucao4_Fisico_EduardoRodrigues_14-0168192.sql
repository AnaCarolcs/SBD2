﻿-- --------     << aula3exer1Evolucao4 >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- date Criacao ...........: 07/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
--                           Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySql
-- Base de Dados(nome) ....: aula3exer1Evolucao4
-- 
-- date Ultima Alteracao ..: 14/10/2019
--   => Criação de tabelas
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--         => 02 Views
--         => 03 Usuários
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula3exer1Evolucao4;

USE aula3exer1Evolucao4;

CREATE TABLE SETOR (
    idSetor int NOT NULL auto_increment,
    nomeSetor VARCHAR(30) NOT NULL,
    CONSTRAINT SETOR_PK PRIMARY KEY(idSetor)
)Engine=InnoDb auto_increment=1;


CREATE TABLE ESPECIALIDADE (
    idEspecialidade int NOT NULL auto_increment,
    tipoEspecialidade VARCHAR(50) NOT NULL,
    CONSTRAINT ESPECIALIDADE_PK PRIMARY KEY(idEspecialidade)
)Engine=InnoDb auto_increment=1;


CREATE TABLE PLANTONISTA (
    matricula bigint NOT NULL auto_increment,
    nome VARCHAR(40) NOT NULL,
    sexo enum('M', 'F') NOT NULL,
    idEspecialidade int DEFAULT 0,
    CONSTRAINT PLANTONISTA_PK PRIMARY KEY(matricula),
    CONSTRAINT PLANTONISTA_ESPECIALIDADE_FK FOREIGN KEY(idEspecialidade)
     REFERENCES ESPECIALIDADE(idEspecialidade)
       ON DELETE RESTRICT
       ON UPDATE RESTRICT
)Engine=InnoDb auto_increment=1;


CREATE TABLE alocado (
    idSetor int NOT NULL,
    matricula bigint NOT NULL,
    datahora datetime NOT NULL,
    CONSTRAINT alocado_UK UNIQUE (matricula, datahora),
    CONSTRAINT alocado_SETOR_FK FOREIGN KEY(idSetor)
     REFERENCES SETOR(idSetor)
       ON DELETE RESTRICT
       ON UPDATE RESTRICT,
    CONSTRAINT alocado_PLANTONISTA_FK FOREIGN KEY(matricula)
     REFERENCES PLANTONISTA(matricula)
       ON DELETE RESTRICT
       ON UPDATE RESTRICT
)Engine=InnoDb;
