﻿-- --------     << aula3exer1Evolucao4 >>     ------------
--
--                    SCRIPT DE CONTROLE (DDL\DCL)
--
-- date Criacao ...........: 07/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
--                           Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySql
-- Base de Dados(nome) ....: aula3exer1Evolucao4
--
-- date Ultima Alteracao ..: 14/10/2019
--   => Cria usuários e define permissões
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--         => 02 Views
--         => 03 Usuários
-- -----------------------------------------------------------------

USE aula3exer1Evolucao4;

-- USUARIO ADMINISTRADOR
CREATE USER 'administrador' identified by 'admin';

GRANT ALL PRIVILEGES ON aula3exer1Evolucao4.*
  TO administrador;


-- USUARIO GESTOR
CREATE USER 'gestor' identified by 'gestor';

GRANT SELECT ON aula3exer1Evolucao4.*
  TO gestor;

GRANT INSERT, UPDATE ON aula3exer1Evolucao4.PLANTONISTA
  TO gestor;

GRANT INSERT, UPDATE ON aula3exer1Evolucao4.SETOR
  TO gestor;


-- USUARIO USUARIO
CREATE USER 'usuario' identified by 'user';

GRANT SELECT ON aula3exer1Evolucao4.*
  TO usuario;
