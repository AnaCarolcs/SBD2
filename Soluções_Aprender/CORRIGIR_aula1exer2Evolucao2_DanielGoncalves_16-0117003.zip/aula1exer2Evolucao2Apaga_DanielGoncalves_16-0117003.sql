/*
-- --------            << aula1exer2Evolucao2 >>        ------------ --
--                                                                   --
--                    SCRIPT APAGA (DDL)                             --
--                                                                   --
-- Data Criacao ..........: 20/08/2019                               --
-- Autor(es) .............: Daniel Maike Mendes Gonçalves            --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: aula1exer2Evolucao2                      --
--                                                                   --
-- Data Ultima Alteracao ..: 20/08/2019                              --
--    + Deletando todas as tabelas uma por vez                       --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 8 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --
*/

use aula1exer2Evolucao2;

DROP TABLE telefone;
DROP TABLE possui;
DROP TABLE PRODUTO;
DROP TABLE AREA;
DROP TABLE VENDA;
DROP TABLE GERENTE;
DROP TABLE EMPREGADO;
DROP TABLE PESSOA;