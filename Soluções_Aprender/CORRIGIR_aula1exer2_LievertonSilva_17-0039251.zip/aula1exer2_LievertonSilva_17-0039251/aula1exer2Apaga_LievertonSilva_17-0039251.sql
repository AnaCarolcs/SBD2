-- --------     << VENDAS >>     ------------
-- 
--                    SCRIPT DE APAGA (DDL)
-- 
-- Data Criacao ...........: 19/08/2019
-- Autor(es) ..............: Lieverton Silva
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: aula1exer2
-- 
-- Data Ultima Alteracao ..: 19/08/2019
--   => Criacao do script que apaga
-- 
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula1exer2;

DROP TABLE vende;

DROP TABLE PRODUTO;

DROP TABLE AREA;

DROP TABLE supervisiona;

DROP TABLE telefone;

DROP TABLE EMPREGADO;

DROP TABLE GERENTE;

DROP TABLE PESSOA;
