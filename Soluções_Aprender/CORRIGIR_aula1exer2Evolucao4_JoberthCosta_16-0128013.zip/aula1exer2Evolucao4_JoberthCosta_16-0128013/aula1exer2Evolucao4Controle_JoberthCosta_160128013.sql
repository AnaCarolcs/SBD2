/*
-- --------            << aula1exer2Evolucao4 >>        ------------ --
--                                                                   --
--                    SCRIPT CONTROLE (DDL)                          --
--                                                                   --
-- Data Criacao ..........: 10/09/2019                               --
-- Autor(es) .............: Joberth Rogers Tavares Costa             --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: aula1exer2Evolucao4                      --
--                                                                   --
-- Data Ultima Alteracao ..: 10/09/2019                              --
--    + Deletando todas as tabelas uma por vez                       --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 8 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --
*/

USE aula1exer2Evolucao3;

CREATE USER 'joberth' IDENTIFIED BY 'goiaba10';
GRANT ALL PRIVILEGES ON aula1exer2Evolucao4.* TO joberth; 

CREATE USER 'shimano' IDENTIFIED BY 'goiaba20';
GRANT SELECT ON aula1exer2Evolucao4 TO 'shimano';