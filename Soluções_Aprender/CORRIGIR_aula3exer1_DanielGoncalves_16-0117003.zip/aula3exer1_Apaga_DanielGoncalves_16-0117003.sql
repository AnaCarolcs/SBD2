-- --------            << aula3exer1 >>                 ------------ --
--                                                                   --
--                    SCRIPT APAGA (DDL)                             --
--                                                                   --
-- Data Criacao ..........: 27/09/2019                               --
-- Autor(es) .............: Daniel Maike Mendes Gonçalves            --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: aula3exer1                               --
--                                                                   --
-- Data Ultima Alteracao ..: 27/09/2019                              --
--    + Deletando todas as tabelas uma por vez                       --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 6 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --

use aula3exer1;

DROP TABLE possui;
DROP TABLE faz;
DROP TABLE PLANTAO;
DROP TABLE ESPECIALIDADE;
DROP TABLE SETOR;
DROP TABLE PLANTONISTA;