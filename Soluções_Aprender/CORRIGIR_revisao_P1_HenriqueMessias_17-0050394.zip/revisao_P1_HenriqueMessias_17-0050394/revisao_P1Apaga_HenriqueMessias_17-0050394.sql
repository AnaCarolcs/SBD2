-- --------     << bdSistema >>     ------------
-- 
--                    SCRIPT DE MANIPULACAO (DML)
-- 
-- date Criacao ...........: 12/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: bdSistema
-- 
-- date Ultima Alteracao ..: 12/10/2019
--   => Criacao das instrucoes DROP
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--         => 02 Usuarios
--         => 01 Visao 
-- 
-- -----------------------------------------------------------------
USE bdSistema;

DROP TABLE possui;
DROP TABLE atende;
DROP TABLE DEPENDENTE;
DROP TABLE SERVICO;
DROP TABLE email;
DROP TABLE USUARIO;
DROP TABLE ADMINISTRADOR;
DROP TABLE PESSOA;