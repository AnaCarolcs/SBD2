-- --------     << bdSistema >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- date Criacao ...........: 12/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: bdSistema
-- 
-- date Ultima Alteracao ..: 12/10/2019
--   => Criacao das tabelas
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--         => 02 Usuarios
--         => 01 Visao 
-- 
-- -----------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS bdSistema;
USE bdSistema;

CREATE TABLE PESSOA (
    matricula INT(8) NOT NULL AUTO_INCREMENT,
    nome VARCHAR(40) NOT NULL,
    senha VARCHAR(30) NOT NULL,
    CONSTRAINT PESSOA_PK PRIMARY KEY(matricula)
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE ADMINISTRADOR (
    matricula INT(8) NOT NULL,
    bairro VARCHAR(30) NOT NULL,
    numero INT(4) NOT NULL,
    rua VARCHAR(30) NOT NULL,
    telefone BIGINT(12) NOT NULL,
    CONSTRAINT ADMINISTRADOR_PESSOA_FK FOREIGN KEY(matricula) REFERENCES PESSOA(matricula),
    CONSTRAINT ADMINISTRADOR_PK PRIMARY KEY(matricula)
) ENGINE=InnoDB;

CREATE TABLE USUARIO (
	matricula INT(8) NOT NULL,
    cpf BIGINT(11) NOT NULL,
    dataDeNascimento DATE NOT NULL,
    CONSTRAINT USUARIO_PESSOA_FK FOREIGN KEY(matricula) REFERENCES PESSOA(matricula),
    CONSTRAINT USUARIO_PK PRIMARY KEY(matricula)
) ENGINE=InnoDB;

CREATE TABLE email (
    email VARCHAR(30) NOT NULL,
    matricula INT(8) NOT NULL,
    CONSTRAINT email_USUARIO_FK FOREIGN KEY(matricula) REFERENCES USUARIO(matricula),
    CONSTRAINT email_PK PRIMARY KEY(email)
) ENGINE=InnoDB;

CREATE TABLE SERVICO (
    codigo INT(7) NOT NULL AUTO_INCREMENT,
    dataInicial DATE NOT NULL,
    preco DECIMAL(9,2) NOT NULL,
    matricula INT(8) NOT NULL,
    CONSTRAINT SERVICO_USUARIO_FK FOREIGN KEY(matricula) REFERENCES USUARIO(matricula),
    CONSTRAINT SERVICO_PK PRIMARY KEY(codigo)
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE DEPENDENTE (
    identificador INT(5) NOT NULL AUTO_INCREMENT,
    nome VARCHAR(40) NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
    CONSTRAINT DEPENDENTE_PK PRIMARY KEY(identificador)
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE atende (
    matriculaAdmin INT(8) NOT NULL,
    matriculaUsuario INT(8) NOT NULL,
    CONSTRAINT atende_ADMINISTRADOR_FK FOREIGN KEY(matriculaAdmin) REFERENCES ADMINISTRADOR(matricula),
    CONSTRAINT atende_USUARIO_FK FOREIGN KEY(matriculaUsuario) REFERENCES USUARIO(matricula)
) ENGINE=InnoDB;

CREATE TABLE possui (
    matricula INT(8) NOT NULL,
    identificador INT(5) NOT NULL,
    CONSTRAINT possui_USUARIO_FK FOREIGN KEY(matricula) REFERENCES USUARIO(matricula),
    CONSTRAINT possui_DEPENDENTE_FK FOREIGN KEY(identificador) REFERENCES DEPENDENTE(identificador)
) ENGINE=InnoDB;