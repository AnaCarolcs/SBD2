-- --------     << bdSistema >>     ------------
-- 
--                    SCRIPT DE MANIPULACAO (DML)
-- 
-- date Criacao ...........: 12/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: bdSistema
-- 
-- date Ultima Alteracao ..: 12/10/2019
--   => Criacao das insercoes
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--         => 02 Usuarios
--         => 01 Visao 	  
-- 
-- -----------------------------------------------------------------
USE bdSistema;

INSERT INTO PESSOA (nome, senha) VALUES
('João da Silva', 'UuSL2yZNoX0c4im'),
('João Pedro', 'uKFHPBkG8YjKzd5'),
('Ana de Souza', 'xypFAi3ZxhxnArL'),
('Maria de Fátima', 'ndXskmuLtsjT4Yx'),
('Lucas Matheus', 'zLkfQlEJB2ryfrg'),
('Fernanda de Jesus', 'rU9EEjrzuciUwct');

INSERT INTO ADMINISTRADOR (matricula, bairro, numero, rua, telefone) VALUES
(2, 'Bairro da Liberdade', 34, 'Rua das Farmácias', 061982605443),
(3, 'Bairro da Penha', 5, 'Rua Dom Bosco', 061900522082),
(4, 'Bairro das Laranjeiras', 1008, 'Rua das Pitangueiras', 061911443425);

INSERT INTO USUARIO (matricula, cpf, dataDeNascimento) VALUES
(1, 92382533411, '1988-04-12'),
(5, 34534526190, '1975-02-05'),
(6, 65800732822, '1991-11-11');

INSERT INTO email (email, matricula) VALUES
('lukinha0502@gmail.com', 5),
('fer.jes@hotmail.com', 6),
('joaomulekedoido@gmail.com', 1);

INSERT INTO SERVICO (dataInicial, preco, matricula) VALUES
('2019-06-11', 299.99, 1),
('2019-10-09', 1599.99, 1),
('2019-08-22', 899.99, 6);

INSERT INTO DEPENDENTE (nome, sexo) VALUES
('Pedro de Lira', 'M'),
('Luísa Ribeiro', 'F'),
('Vinícius da Silva', 'M');

INSERT INTO atende (matriculaAdmin, matriculaUsuario) VALUES
(3, 5),
(2, 1),
(4, 6);

INSERT INTO possui (matricula, identificador) VALUES
(1, 2),
(6, 1),
(5, 3);