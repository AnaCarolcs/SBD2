-- --------     << bdSistema >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- date Criacao ...........: 12/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: bdSistema
-- 
-- date Ultima Alteracao ..: 12/10/2019
--   => Criacao dos usuarios
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--         => 02 Usuarios
--         => 01 Visao 
-- 
-- -----------------------------------------------------------------
USE bdSistema;

CREATE USER 'presidente'@'bdSistema' IDENTIFIED BY 'passwordpresidente123';
GRANT ALL PRIVILEGES ON bdSistema.* TO presidente;

CREATE USER 'secretario'@'bdSistema' IDENTIFIED BY 'passwordsecret123';
GRANT SELECT, INSERT, UPDATE ON bdSistema.PESSOA TO secretario;
GRANT SELECT, INSERT, UPDATE ON bdSistema.USUARIO TO secretario;
GRANT SELECT, INSERT, UPDATE ON bdSistema.ADMINISTRADOR TO secretario;