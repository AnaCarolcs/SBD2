-- --------     << bdSistema >>     ------------
-- 
--                    SCRIPT DE MANIPULACAO (DML)
-- 
-- date Criacao ...........: 12/10/2019
-- Autor(es) ..............: Henrique Martins de Messias
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: bdSistema
-- 
-- date Ultima Alteracao ..: 12/10/2019
--   => Criacao da View
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--         => 02 Usuarios
--         => 01 Visao 
-- 
-- -----------------------------------------------------------------
USE bdSistema;

-- View que guarda os dados dos preços e a data dos serviços de cada usuário
CREATE OR REPLACE VIEW V_SERVICOS_USUARIO (usuario, data, preco) AS
SELECT p.nome, s.dataInicial, s.preco
FROM USUARIO u JOIN PESSOA p ON p.matricula = u.matricula JOIN SERVICO s ON s.matricula = u.matricula
ORDER BY p.nome, s.dataInicial;

-- Select que mostra o nome, cpf e email dos usuários
SELECT p.nome, u.cpf, e.email
FROM EMAIL e, USUARIO u JOIN PESSOA p ON p.matricula = u.matricula
WHERE e.matricula = u.matricula
ORDER BY p.nome;