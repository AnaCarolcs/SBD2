﻿-- ------------------ << aula1exer2Evolucao4 >> ------------------ --
-- 								                                                --
-- 		                	SCRIPT DE CONTROLE 			                 --
-- 								                                                --
-- Data Criacao ..........: 08/09/2019  			                     --
-- Autor(es) .............: Ana Carolina Carvalho da Silva 	      --
-- Banco de Dados ........: MySQL 				                         --
-- Base de Dados(nome) ...: aula1exer2Evolucao4 			             --
-- 								                                                --
-- Data Ultima Alteracao ..: 10/09/2019                            --
--    + Organizando instrucoes de criacao dos usuarios             --
--    + Criando instrucoes de apoio que apagam usuarios do projeto --
--                                                                 --
-- PROJETO => 1 Base de Dados  					                          --
--         => 2 Usuarios		 				                              --
--         => 8 Tabelas 		 				                              --
-- 								                                                --
-- --------------------------------------------------------------- --

-- Administrador: possui todos os privilegios sobre essa base
-- de dados somente.

 CREATE USER 'administrador'
  IDENTIFIED BY 'ana123';

 GRANT ALL PRIVILEGES ON aula1exer2Evolucao4.*
  TO administrador;



-- Usuario: possui somente o privilegio de consulta de dados
-- sobre a base de dados desse projeto somente.

 CREATE USER 'rafael'
  IDENTIFIED BY 'rafa123';

 GRANT SELECT ON aula1exer2Evolucao4.*
  TO rafael;




-- =========== APOIO NA MANUTENCAO DO PROJETO ============
--
-- Apagando usuarios que operam somente nesse projeto
--   DROP USER administrador;
--   DROP USER rafael;

