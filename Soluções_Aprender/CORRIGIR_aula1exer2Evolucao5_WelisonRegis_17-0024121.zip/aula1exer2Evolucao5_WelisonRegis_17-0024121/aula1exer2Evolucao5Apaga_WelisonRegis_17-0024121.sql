-- --------     << CONTROLE DE VENDAS >>     ------------
-- 
--                    SCRIPT DE APAGA (DDL)
-- 
-- Data Criacao ...........: 26/08/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: aula1exer2Evolucao5
-- 
-- Data Ultima Alteracao ..: 15/09/2019
--   => Criacao do script que apaga
-- 
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula1exer2Evolucao5;

DROP TABLE contem;
DROP TABLE PRODUTO;
DROP TABLE VENDA;
DROP TABLE AREA;
DROP TABLE supervisiona;
DROP TABLE telefone;
DROP TABLE EMPREGADO;
DROP TABLE GERENTE;
DROP TABLE PESSOA;
